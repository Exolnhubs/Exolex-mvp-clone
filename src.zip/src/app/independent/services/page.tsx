'use client'

import ServicesManager from '@/components/services/ServicesManager'

export default function IndependentServicesPage() {
  return <ServicesManager providerType="independent" />
}
