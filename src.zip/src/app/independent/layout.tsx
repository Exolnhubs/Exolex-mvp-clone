'use client'

import { useState, useEffect } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'

const menuItems = [
  { id: 'dashboard', label: 'لوحة التحكم', icon: '🏠', href: '/independent/dashboard' },
  { id: 'offers', label: 'العروض', icon: '📨', href: '/independent/offers', badge: 'new' },
  { id: 'requests', label: 'الطلبات', icon: '📋', href: '/independent/requests' },
  { id: 'cases', label: 'القضايا', icon: '⚖️', href: '/independent/cases' },
  { id: 'contracts', label: 'العقود', icon: '📝', href: '/independent/contracts' },
  { id: 'services', label: 'الخدمات', icon: '🔧', href: '/independent/services' },
  { id: 'calendar', label: 'التقويم', icon: '📅', href: '/independent/calendar' },
  { id: 'documents', label: 'المستندات', icon: '📁', href: '/independent/documents' },
  { id: 'earnings', label: 'الأرباح', icon: '💰', href: '/independent/earnings' },
  { id: 'ratings', label: 'التقييمات', icon: '⭐', href: '/independent/ratings' },
  { id: 'reports', label: 'التقارير', icon: '📈', href: '/independent/reports' },
  { type: 'divider' },
  { id: 'support', label: 'مركز التواصل', icon: '📞', href: '/independent/support' },
  { id: 'profile', label: 'الملف الشخصي', icon: '👤', href: '/independent/profile' },
  { id: 'settings', label: 'الإعدادات', icon: '⚙️', href: '/independent/settings' },
  { id: 'notifications', label: 'الإشعارات', icon: '🔔', href: '/independent/notifications', badge: '5' },
]

export default function IndependentLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const pathname = usePathname()
  const [lawyer, setLawyer] = useState<any>(null)
  const [isAvailable, setIsAvailable] = useState(true)
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    const lawyerId = localStorage.getItem('exolex_lawyer_id')
    if (!lawyerId && !pathname.includes('/register')) {
      router.push('/auth/lawyer-login')
      return
    }
    if (lawyerId) {
      supabase.from('lawyers').select('id, full_name, is_available, average_rating, profile_image').eq('id', lawyerId).single()
        .then(({ data }) => { if (data) { setLawyer(data); setIsAvailable(data.is_available ?? true) } })
    }
  }, [pathname, router])

  const toggleAvailability = async () => {
    const newStatus = !isAvailable
    setIsAvailable(newStatus)
    const lawyerId = localStorage.getItem('exolex_lawyer_id')
    if (lawyerId) await supabase.from('lawyers').update({ is_available: newStatus }).eq('id', lawyerId)
  }

  const handleLogout = () => {
    localStorage.removeItem('exolex_lawyer_id')
    localStorage.removeItem('exolex_user_id')
    router.push('/auth/lawyer-login')
  }

  const isActive = (href: string) => href === '/independent/dashboard' ? pathname === href : pathname.startsWith(href)

  if (pathname.includes('/register')) return <>{children}</>

  return (
    <div className="min-h-screen bg-slate-100" dir="rtl">
      <aside className={`fixed top-0 right-0 h-full bg-slate-900 text-white z-40 transition-all duration-300 ${isSidebarOpen ? 'w-64' : 'w-20'} hidden lg:block`}>
        <div className="p-4 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl flex items-center justify-center">
              <span className="text-xl">⚖️</span>
            </div>
            {isSidebarOpen && <div><h1 className="font-bold text-lg">ExoLex</h1><p className="text-xs text-slate-400">بوابة المحامي</p></div>}
          </div>
        </div>

        {lawyer && (
          <div className="p-4 border-b border-slate-700">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-slate-700 rounded-full flex items-center justify-center">
                <span className="text-lg">👤</span>
              </div>
              {isSidebarOpen && (
                <div className="flex-1">
                  <p className="font-medium truncate">{lawyer.full_name}</p>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-yellow-400">⭐ {lawyer.average_rating?.toFixed(1) || '0.0'}</span>
                    <button onClick={toggleAvailability} className={`px-1.5 py-0.5 rounded text-[10px] ${isAvailable ? 'bg-green-500/20 text-green-400' : 'bg-slate-500/20 text-slate-400'}`}>
                      {isAvailable ? 'متاح' : 'غير متاح'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        <nav className="p-3 space-y-1 overflow-y-auto" style={{ maxHeight: 'calc(100vh - 250px)' }}>
          {menuItems.map((item, index) => {
            if (item.type === 'divider') return <div key={index} className="border-t border-slate-700 my-3"></div>
            const active = isActive(item.href!)
            return (
              <Link key={item.id} href={item.href!} className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${active ? 'bg-amber-500 text-white' : 'text-slate-300 hover:bg-slate-800'} ${isSidebarOpen ? '' : 'justify-center'}`}>
                <span className="text-xl">{item.icon}</span>
                {isSidebarOpen && <><span className="flex-1">{item.label}</span>{item.badge && <span className={`px-2 py-0.5 rounded-full text-xs ${item.badge === 'new' ? 'bg-green-500' : 'bg-red-500'}`}>{item.badge === 'new' ? 'جديد' : item.badge}</span>}</>}
              </Link>
            )
          })}
        </nav>

        <div className="absolute bottom-16 left-0 right-0 px-3">
          <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="w-full flex items-center justify-center gap-2 px-3 py-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg">
            <span>{isSidebarOpen ? '←' : '→'}</span>
            {isSidebarOpen && <span className="text-sm">طي القائمة</span>}
          </button>
        </div>

        <div className="absolute bottom-4 left-0 right-0 px-3">
          <button onClick={handleLogout} className="w-full flex items-center justify-center gap-2 px-3 py-2 text-red-400 hover:bg-red-500/10 rounded-lg">
            <span>🚪</span>
            {isSidebarOpen && <span className="text-sm">تسجيل الخروج</span>}
          </button>
        </div>
      </aside>

      <header className="lg:hidden fixed top-0 left-0 right-0 bg-white shadow-sm z-50">
        <div className="flex items-center justify-between px-4 py-3">
          <button onClick={() => setIsMobileMenuOpen(true)} className="p-2 hover:bg-slate-100 rounded-lg">
            <span className="text-2xl">☰</span>
          </button>
          <div className="flex items-center gap-2">
            <span className="text-xl">⚖️</span>
            <span className="font-bold">ExoLex</span>
          </div>
          <button onClick={toggleAvailability} className={`w-3 h-3 rounded-full ${isAvailable ? 'bg-green-500' : 'bg-slate-400'}`} />
        </div>
      </header>

      {isMobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsMobileMenuOpen(false)} />
          <aside className="absolute top-0 right-0 h-full w-72 bg-slate-900 text-white">
            <div className="p-4 border-b border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-2xl">⚖️</span>
                <span className="font-bold">ExoLex</span>
              </div>
              <button onClick={() => setIsMobileMenuOpen(false)} className="p-2 hover:bg-slate-800 rounded-lg">✕</button>
            </div>
            
            {lawyer && (
              <div className="p-4 border-b border-slate-700">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-slate-700 rounded-full flex items-center justify-center">
                    <span className="text-xl">👤</span>
                  </div>
                  <div>
                    <p className="font-medium">{lawyer.full_name}</p>
                    <button onClick={toggleAvailability} className={`text-xs px-2 py-1 rounded mt-1 ${isAvailable ? 'bg-green-500/20 text-green-400' : 'bg-slate-500/20 text-slate-400'}`}>
                      {isAvailable ? '🟢 متاح' : '⚫ غير متاح'}
                    </button>
                  </div>
                </div>
              </div>
            )}
            
            <nav className="p-3 space-y-1 overflow-y-auto" style={{ maxHeight: 'calc(100vh - 180px)' }}>
              {menuItems.map((item, index) => {
                if (item.type === 'divider') return <div key={index} className="border-t border-slate-700 my-3"></div>
                const active = isActive(item.href!)
                return (
                  <Link key={item.id} href={item.href!} onClick={() => setIsMobileMenuOpen(false)} className={`flex items-center gap-3 px-3 py-3 rounded-lg ${active ? 'bg-amber-500 text-white' : 'text-slate-300 hover:bg-slate-800'}`}>
                    <span className="text-xl">{item.icon}</span>
                    <span className="flex-1">{item.label}</span>
                    {item.badge && <span className={`px-2 py-0.5 rounded-full text-xs ${item.badge === 'new' ? 'bg-green-500' : 'bg-red-500'}`}>{item.badge === 'new' ? 'جديد' : item.badge}</span>}
                  </Link>
                )
              })}
            </nav>
            
            <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-slate-700">
              <button onClick={handleLogout} className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-red-500/10 text-red-400 rounded-lg">
                <span>🚪</span>
                <span>تسجيل الخروج</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      <main className={`transition-all duration-300 ${isSidebarOpen ? 'lg:mr-64' : 'lg:mr-20'} pt-14 lg:pt-0`}>
        {children}
      </main>
    </div>
  )
}
