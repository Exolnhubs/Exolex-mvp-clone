'use client'

export const dynamic = 'force-dynamic'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import Link from 'next/link'
import Sidebar from '@/components/layout/Sidebar'

interface User {
  id: string
  full_name: string
  phone: string
  email: string
  national_id: string
}

interface Subscription {
  id: string
  status: string
  package_name: string
  consultations_remaining: number
  cases_remaining: number
  nolex_remaining: number
  library_remaining: number
}

interface ExtraService {
  id: string
  name_ar: string
  description_ar: string | null
  price: number | null
  pricing_type: string
  icon: string | null
  category?: {
    code: string
    name_ar: string
    color: string
    icon: string
  }
}

// تحويل أسماء Lucide إلى Emoji
const ICON_MAP: { [key: string]: string } = {
  'globe': '🌐', 'file-text': '📄', 'stamp': '✍️', 'zap': '⚡',
  'scale': '⚖️', 'briefcase': '💼', 'building': '🏢', 'users': '👥',
  'shield': '🛡️', 'home': '🏠', 'file-signature': '📝',
}

const getIcon = (iconName: string | null): string => {
  if (!iconName) return '📦'
  if (/[\u{1F300}-\u{1F9FF}]/u.test(iconName)) return iconName
  return ICON_MAP[iconName.toLowerCase()] || '📦'
}

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [subscription, setSubscription] = useState<Subscription | null>(null)
  const [extraServices, setExtraServices] = useState<ExtraService[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [nolexUsed, setNolexUsed] = useState(0)
  const FREE_NOLEX_LIMIT = 10

  useEffect(() => {
    const userId = localStorage.getItem('exolex_user_id')
    
    if (!userId) {
      router.push('/auth/login')
      return
    }

    const fetchData = async () => {
      // جلب بيانات المستخدم
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single()

      if (userError || !userData) {
        localStorage.removeItem('exolex_user_id')
        router.push('/auth/login')
        return
      }

      if (!userData.is_profile_complete) {
        router.push('/auth/complete-profile')
        return
      }

      setUser(userData)

      // جلب member_id أولاً
      const { data: memberData } = await supabase.from('members').select('id, free_searches_remaining').eq('user_id', userId).single()
      
      // جلب بيانات الاشتراك (إذا وجد)
      const { data: subData } = await supabase
        .from('subscriptions')
        .select('*, packages(*)')
        .eq('member_id', memberData?.id)
        .eq('status', 'active')
        .single()

      if (subData) {
        setSubscription({
          id: subData.id,
          status: subData.status,
          package_name: subData.packages?.name_ar || 'غير معروف',
          consultations_remaining: subData.consultations_remaining || 0,
          cases_remaining: subData.cases_remaining || 0,
          nolex_remaining: subData.nolex_remaining || 0,
          library_remaining: subData.library_remaining || 0,
        })
      }

      // جلب الخدمات الإضافية من DB (أول 6 فقط)
      const { data: servicesData } = await supabase
        .from('extra_services')
        .select('id, name_ar, description_ar, price, pricing_type, icon, category:categories(code, name_ar, color, icon)')
        .eq('is_active', true)
        .order('sort_order')
        .limit(6)

      if (servicesData) {
        setExtraServices(servicesData)
      }

      // جلب عدد استخدامات NOLEX (للمجاني)
      // جلب رصيد البحث من members
      if (memberData) {
        setNolexUsed(FREE_NOLEX_LIMIT - (memberData.free_searches_remaining || 0))
      }
      setIsLoading(false)
    }

    fetchData()
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem('exolex_user_id')
    localStorage.removeItem('exolex_phone')
    router.push('/auth/login')
  }

  // تنسيق السعر
  const formatPrice = (service: ExtraService): string => {
    if (service.pricing_type === 'quote' || service.price === null) {
      return 'طلب عرض سعر'
    }
    return `${Number(service.price).toLocaleString('ar-SA')} ريال`
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  const isSubscribed = !!subscription

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <Sidebar 
        isSubscribed={isSubscribed} 
        userName={user?.full_name || ''} 
        onLogout={handleLogout}
      />

      {/* Main Content */}
      <main className="flex-1 mr-64 p-8">
        {/* Welcome */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-800">مرحباً، {user?.full_name} 👋</h1>
          <p className="text-gray-500 mt-1">نتمنى لك يوماً سعيداً</p>
        </div>

        {/* Subscription Status Card */}
        {!isSubscribed ? (
          // غير مشترك
          <div className="card mb-8 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-l from-gray-100 to-transparent opacity-50"></div>
            <div className="relative">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center">
                  <span className="text-3xl">⚠️</span>
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-800">أنت غير مشترك حالياً</h2>
                  <p className="text-gray-500">اشترك الآن للحصول على حماية قانونية كاملة</p>
                </div>
              </div>

              {/* خدمات الباقة - مظللة */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 opacity-60">
                <div className="bg-gray-100 rounded-xl p-4 text-center">
                  <span className="text-2xl mb-2 block">💬</span>
                  <p className="text-sm font-medium text-gray-600">الاستشارات</p>
                  <p className="text-xs text-gray-400">الرصيد: --</p>
                </div>
                <div className="bg-gray-100 rounded-xl p-4 text-center">
                  <span className="text-2xl mb-2 block">⚖️</span>
                  <p className="text-sm font-medium text-gray-600">القضايا</p>
                  <p className="text-xs text-gray-400">الرصيد: --</p>
                </div>
                <div className="bg-gray-100 rounded-xl p-4 text-center">
                  <span className="text-2xl mb-2 block">🤖</span>
                  <p className="text-sm font-medium text-gray-600">NOLEX AI</p>
                  <p className="text-xs text-gray-400">الرصيد: --</p>
                </div>
                <div className="bg-gray-100 rounded-xl p-4 text-center">
                  <span className="text-2xl mb-2 block">📚</span>
                  <p className="text-sm font-medium text-gray-600">المكتبة</p>
                  <p className="text-xs text-gray-400">الرصيد: --</p>
                </div>
              </div>

              <Link href="/subscriber/subscription">
                <button className="btn-primary">
                  اشترك الآن واحصل على حماية قانونية كاملة
                </button>
              </Link>
            </div>
          </div>
        ) : (
          // مشترك
          <div className="card mb-8 border-2 border-green-200 bg-green-50">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <span className="text-3xl">✓</span>
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-800">باقة {subscription.package_name}</h2>
                <p className="text-green-600">اشتراك فعّال</p>
              </div>
            </div>

            {/* خدمات الباقة - واضحة */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white rounded-xl p-4 text-center shadow-sm">
                <span className="text-2xl mb-2 block">💬</span>
                <p className="text-sm font-medium text-gray-600">الاستشارات</p>
                <p className="text-lg font-bold text-primary-600">{subscription.consultations_remaining}</p>
              </div>
              <div className="bg-white rounded-xl p-4 text-center shadow-sm">
                <span className="text-2xl mb-2 block">⚖️</span>
                <p className="text-sm font-medium text-gray-600">القضايا</p>
                <p className="text-lg font-bold text-primary-600">{subscription.cases_remaining}</p>
              </div>
              <div className="bg-white rounded-xl p-4 text-center shadow-sm">
                <span className="text-2xl mb-2 block">🤖</span>
                <p className="text-sm font-medium text-gray-600">NOLEX AI</p>
                <p className="text-lg font-bold text-primary-600">
                  {subscription.nolex_remaining === -1 ? '∞' : subscription.nolex_remaining}
                </p>
              </div>
              <div className="bg-white rounded-xl p-4 text-center shadow-sm">
                <span className="text-2xl mb-2 block">📚</span>
                <p className="text-sm font-medium text-gray-600">المكتبة</p>
                <p className="text-lg font-bold text-primary-600">
                  {subscription.library_remaining === -1 ? '∞' : subscription.library_remaining}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* NOLEX Section */}
        <div className="card mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <img src="/nolex-avatar.jpg" alt="NOLEX" className="w-12 h-12 rounded-full object-cover" />
              <div>
                <h3 className="text-lg font-semibold">NOLEX - المساعد القانوني الذكي</h3>
                <p className="text-sm text-gray-500">اسأل أي سؤال قانوني واحصل على إجابة فورية</p>
              </div>
            </div>
            {!isSubscribed && (
              <div className="text-sm text-amber-600 bg-amber-50 px-3 py-1 rounded-full">
                {FREE_NOLEX_LIMIT - nolexUsed} استخدام متبقي
              </div>
            )}
          </div>
          <Link href="/subscriber/nolex">
            <div className="bg-gray-100 rounded-lg p-4 hover:bg-gray-200 transition-colors cursor-pointer">
              <div className="flex items-center gap-3 text-gray-500">
                <span>💬</span>
                <span>اسأل NOLEX أي سؤال قانوني...</span>
              </div>
            </div>
          </Link>
          <p className="text-xs text-gray-400 mt-2">
            أمثلة: "ما هي حقوقي كعامل؟" | "كيف أرفع قضية عمالية؟" | "ما إجراءات الطلاق؟"
          </p>
        </div>

        {/* المكتبة القانونية */}
        <div className="card mb-8">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-3xl">📚</span>
            <div>
              <h3 className="text-lg font-semibold">المكتبة القانونية الرقمية</h3>
              <p className="text-sm text-gray-500">أكثر من 100,000 وثيقة ونظام وحكم قضائي</p>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-primary-50 rounded-lg p-4 text-center hover:bg-primary-100 transition-colors cursor-pointer">
              <span className="text-2xl mb-2 block">📜</span>
              <p className="text-sm font-medium">الأنظمة السعودية</p>
            </div>
            <div className="bg-primary-50 rounded-lg p-4 text-center hover:bg-primary-100 transition-colors cursor-pointer">
              <span className="text-2xl mb-2 block">⚖️</span>
              <p className="text-sm font-medium">الأحكام القضائية</p>
            </div>
            <div className="bg-primary-50 rounded-lg p-4 text-center hover:bg-primary-100 transition-colors cursor-pointer">
              <span className="text-2xl mb-2 block">📋</span>
              <p className="text-sm font-medium">نماذج العقود</p>
            </div>
            <div className="bg-primary-50 rounded-lg p-4 text-center hover:bg-primary-100 transition-colors cursor-pointer">
              <span className="text-2xl mb-2 block">📖</span>
              <p className="text-sm font-medium">المراجع القانونية</p>
            </div>
          </div>
        </div>

        {/* الخدمات الإضافية - من قاعدة البيانات */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">الخدمات الإضافية</h3>
            <Link href="/subscriber/extra-services" className="text-primary-600 text-sm hover:underline">
              عرض الكل ←
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {extraServices.map((service) => (
              <Link 
                key={service.id}
                href="/subscriber/extra-services"
                className="block"
              >
                <div 
                  className="bg-white rounded-xl p-4 hover:shadow-lg transition-all cursor-pointer border-2 border-transparent hover:border-opacity-50"
                  style={{ 
                    borderColor: service.category?.color || '#E5E7EB',
                    borderTopWidth: '4px',
                    borderTopColor: service.category?.color || '#6B7280'
                  }}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div 
                      className="w-10 h-10 rounded-lg flex items-center justify-center text-xl"
                      style={{ backgroundColor: `${service.category?.color}20` }}
                    >
                      {getIcon(service.icon || service.category?.icon)}
                    </div>
                    {service.category && (
                      <span 
                        className="text-xs px-2 py-0.5 rounded-full text-white"
                        style={{ backgroundColor: service.category.color }}
                      >
                        {service.category.name_ar}
                      </span>
                    )}
                  </div>
                  <h4 className="font-semibold text-gray-800">{service.name_ar}</h4>
                  <p className="text-xs text-gray-500 mt-1 mb-3 line-clamp-1">
                    {service.description_ar || 'خدمة قانونية متخصصة'}
                  </p>
                  <p 
                    className="font-medium text-sm"
                    style={{ color: service.category?.color || '#2563EB' }}
                  >
                    {formatPrice(service)}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
