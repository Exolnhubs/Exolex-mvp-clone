'use client'

import { useState, useEffect, useRef } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import toast from 'react-hot-toast'
import {
  ArrowRight, Clock, User, FileText, Calendar, MessageSquare,
  Send, Paperclip, Bot, AlertCircle, CheckCircle, XCircle,
  Download, Eye, Timer, Phone, Mail, Star, Upload
} from 'lucide-react'

// ═══════════════════════════════════════════════════════════════════════════════
// 📋 تفاصيل الطلب - المشترك
// تاريخ: 1 يناير 2026
// المشترك يمكنه: عرض التفاصيل، المحادثة مع المحامي، رفع ملفات
// ═══════════════════════════════════════════════════════════════════════════════

const statusConfig: Record<string, { label: string; color: string; icon: any; description: string }> = {
  pending: { 
    label: 'قيد الانتظار', 
    color: 'bg-gray-100 text-gray-700', 
    icon: Clock,
    description: 'طلبك قيد المراجعة وسيتم تعيين محامي قريباً'
  },
  assigned: { 
    label: 'تم التعيين', 
    color: 'bg-blue-100 text-blue-700', 
    icon: User,
    description: 'تم تعيين محامي لطلبك وبانتظار قبوله'
  },
  accepted: { 
    label: 'مقبول', 
    color: 'bg-green-100 text-green-700', 
    icon: CheckCircle,
    description: 'المحامي قبل طلبك ويعمل عليه'
  },
  in_progress: { 
    label: 'قيد العمل', 
    color: 'bg-indigo-100 text-indigo-700', 
    icon: Timer,
    description: 'المحامي يعمل على طلبك حالياً'
  },
  completed: { 
    label: 'مكتمل', 
    color: 'bg-emerald-100 text-emerald-700', 
    icon: CheckCircle,
    description: 'تم إكمال طلبك بنجاح'
  },
  closed: { 
    label: 'مغلق', 
    color: 'bg-slate-100 text-slate-700', 
    icon: XCircle,
    description: 'تم إغلاق الطلب'
  },
  cancelled: { 
    label: 'ملغي', 
    color: 'bg-red-100 text-red-700', 
    icon: XCircle,
    description: 'تم إلغاء الطلب'
  },
}

const typeConfig: Record<string, { label: string; color: string; icon: string }> = {
  consultation: { label: 'استشارة قانونية', color: 'bg-blue-500', icon: '💬' },
  case: { label: 'قضية', color: 'bg-purple-500', icon: '⚖️' },
  extra_service: { label: 'خدمة إضافية', color: 'bg-orange-500', icon: '✨' },
}

const priorityConfig: Record<string, { label: string; color: string }> = {
  normal: { label: 'عادي', color: 'bg-slate-100 text-slate-600' },
  urgent: { label: 'عاجل', color: 'bg-orange-100 text-orange-600' },
  emergency: { label: 'طارئ', color: 'bg-red-100 text-red-600' },
}

export default function SubscriberRequestDetailsPage() {
  const params = useParams()
  const router = useRouter()
  const requestId = params.id as string
  const fileInputRef = useRef<HTMLInputElement>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // States
  const [isLoading, setIsLoading] = useState(true)
  const [request, setRequest] = useState<any>(null)
  const [messages, setMessages] = useState<any[]>([])
  const [lawyer, setLawyer] = useState<any>(null)

  // معلومات المشترك الحالي
  const [currentUser, setCurrentUser] = useState<{
    id: string;
    memberId: string;
    name: string;
  } | null>(null)

  // التبويب النشط
  const [activeTab, setActiveTab] = useState<'overview' | 'chat' | 'files'>('overview')
  
  // الرسائل
  const [newMessage, setNewMessage] = useState('')
  const [sendingMessage, setSendingMessage] = useState(false)
  const [uploadingFile, setUploadingFile] = useState(false)

  // التمرير لآخر رسالة
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => { loadData() }, [requestId])
  useEffect(() => { scrollToBottom() }, [messages])

  const loadData = async () => {
    try {
      const userId = localStorage.getItem('exolex_user_id')
      if (!userId) {
        router.push('/auth/login')
        return
      }

      // جلب معلومات المشترك
      const { data: memberData, error: memberError } = await supabase
        .from('members')
        .select('id, user_id')
        .eq('user_id', userId)
        .single()

      if (memberError || !memberData) {
        router.push('/auth/login')
        return
      }

      // جلب اسم المستخدم
      const { data: userData } = await supabase
        .from('users')
        .select('full_name')
        .eq('id', userId)
        .single()

      setCurrentUser({
        id: userId,
        memberId: memberData.id,
        name: userData?.full_name || 'مشترك'
      })

      // جلب الطلب
      const { data: requestData, error: requestError } = await supabase
        .from('service_requests')
        .select(`
          *,
          category:category_id(name_ar, icon),
          subcategory:subcategory_id(name_ar)
        `)
        .eq('id', requestId)
        .single()

      if (requestError) throw requestError

      // التحقق من أن الطلب يخص هذا المشترك
      if (requestData.member_id !== memberData.id) {
        toast.error('ليس لديك صلاحية لعرض هذا الطلب')
        router.push('/subscriber/requests')
        return
      }

      setRequest(requestData)

      // جلب معلومات المحامي المعين
      if (requestData.assigned_lawyer_id) {
        const { data: lawyerData } = await supabase
          .from('lawyers')
          .select('id, full_name, email, phone, rating_average, rating_count, years_of_experience, city')
          .eq('id', requestData.assigned_lawyer_id)
          .single()
        setLawyer(lawyerData)
      }

      // رسائل المحادثة
      const { data: messagesData } = await supabase
        .from('messages')
        .select('*')
        .eq('request_id', requestId)
        .eq('private', false)
        .order('created_at', { ascending: true })
      setMessages(messagesData || [])

    } catch (error) {
      console.error('Error:', error)
      toast.error('حدث خطأ في تحميل البيانات')
    } finally {
      setIsLoading(false)
    }
  }

  // إرسال رسالة للمحامي
  const handleSendMessage = async () => {
    if (!newMessage.trim()) return
    if (!['accepted', 'in_progress'].includes(request?.status)) {
      toast.error('لا يمكن إرسال رسائل في هذه الحالة')
      return
    }
    
    setSendingMessage(true)
    try {
      const { error } = await supabase.from('messages').insert({
        request_id: requestId,
        sender_id: currentUser?.memberId,
        sender_type: 'member',
        content: newMessage
      })
      
      if (error) throw error
      
      setNewMessage('')
      loadData()
      toast.success('✅ تم الإرسال')
    } catch (error) {
      console.error('Send error:', error)
      toast.error('حدث خطأ في الإرسال')
    } finally {
      setSendingMessage(false)
    }
  }

  // رفع ملف
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return
    
    if (!['accepted', 'in_progress'].includes(request?.status)) {
      toast.error('لا يمكن رفع ملفات في هذه الحالة')
      return
    }
    
    setUploadingFile(true)
    try {
      const fileName = `subscriber/${requestId}/${Date.now()}_${file.name}`
      const { error: uploadError } = await supabase.storage
        .from('request-files')
        .upload(fileName, file)
      
      if (uploadError) throw uploadError
      
      const { data: urlData } = supabase.storage
        .from('request-files')
        .getPublicUrl(fileName)
      
      // إرسال كرسالة مع مرفق
      await supabase.from('messages').insert({
        request_id: requestId,
        sender_id: currentUser?.memberId,
        sender_type: 'member',
        content: `📎 مرفق: ${file.name}`,
        attachments: [{
          file_url: urlData.publicUrl,
          file_name: file.name,
          file_type: file.type,
          file_size: file.size
        }]
      })
      
      toast.success('✅ تم رفع الملف')
      loadData()
    } catch (error) {
      console.error('Upload error:', error)
      toast.error('حدث خطأ في رفع الملف')
    } finally {
      setUploadingFile(false)
    }
  }

  // الدوال المساعدة
  const formatDate = (date: string) => date ? new Date(date).toLocaleDateString('ar-SA') : '-'
  const formatDateTime = (date: string) => date ? new Date(date).toLocaleString('ar-SA') : '-'
  const formatTime = (date: string) => date ? new Date(date).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }) : ''

  const getSlaStatus = () => {
    if (!request) return null
    if (request.is_sla_breached) {
      return { text: 'تأخر في الرد', color: 'bg-red-500 text-white', icon: '⚠️' }
    }
    if (request.sla_deadline) {
      const remaining = new Date(request.sla_deadline).getTime() - new Date().getTime()
      const hours = Math.floor(remaining / (1000 * 60 * 60))
      if (hours < 0) return { text: 'متأخر', color: 'bg-red-500 text-white', icon: '⚠️' }
      if (hours <= 4) return { text: `متبقي ${hours} ساعة`, color: 'bg-orange-100 text-orange-700', icon: '⏰' }
      if (hours <= 12) return { text: `متبقي ${hours} ساعة`, color: 'bg-yellow-100 text-yellow-700', icon: '⏳' }
      return { text: `متبقي ${hours} ساعة`, color: 'bg-green-100 text-green-700', icon: '✓' }
    }
    return null
  }

  // جمع الملفات من الرسائل
  const getAllFiles = () => {
    const files: any[] = []
    
    // مرفقات الطلب الأصلية
    if (request?.attachments && request.attachments.length > 0) {
      request.attachments.forEach((f: any, idx: number) => {
        files.push({
          ...f,
          source: 'طلب أصلي',
          uploaded_at: request.created_at
        })
      })
    }
    
    // مرفقات الرسائل
    messages.forEach(msg => {
      if (msg.attachments && msg.attachments.length > 0) {
        msg.attachments.forEach((f: any) => {
          files.push({
            ...f,
            source: msg.sender_type === 'member' ? 'أنت' : 'المحامي',
            uploaded_at: msg.created_at
          })
        })
      }
    })
    
    return files
  }

  const canSendMessage = ['accepted', 'in_progress'].includes(request?.status)

  // العرض
  if (isLoading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-500">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  if (!request) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="w-16 h-16 mx-auto text-red-300 mb-4" />
        <h2 className="text-xl font-bold text-slate-800 mb-2">الطلب غير موجود</h2>
        <p className="text-slate-500 mb-4">لم نتمكن من العثور على هذا الطلب</p>
        <button 
          onClick={() => router.push('/subscriber/requests')} 
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          العودة للطلبات
        </button>
      </div>
    )
  }

  const slaStatus = getSlaStatus()
  const StatusIcon = statusConfig[request.status]?.icon || Clock
  const allFiles = getAllFiles()

  return (
    <div className="space-y-4 pb-8">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm p-4">
        <div className="flex items-start gap-4">
          <button 
            onClick={() => router.push('/subscriber/requests')} 
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors mt-1"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          
          <div className="flex-1">
            <div className="flex items-center gap-3 flex-wrap mb-2">
              <span className="text-2xl">{typeConfig[request.request_type]?.icon || '📋'}</span>
              <h1 className="text-xl font-bold text-slate-800">
                {request.ticket_number || `طلب #${requestId.slice(0, 8)}`}
              </h1>
              <span className={`px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1.5 ${statusConfig[request.status]?.color}`}>
                <StatusIcon className="w-4 h-4" />
                {statusConfig[request.status]?.label}
              </span>
            </div>
            
            <p className="text-slate-600 mb-3">{request.title || 'بدون عنوان'}</p>
            
            <div className="flex items-center gap-4 flex-wrap text-sm">
              <span className={`px-2 py-1 rounded text-xs text-white ${typeConfig[request.request_type]?.color}`}>
                {typeConfig[request.request_type]?.label}
              </span>
              <span className={`px-2 py-1 rounded text-xs ${priorityConfig[request.priority]?.color}`}>
                {priorityConfig[request.priority]?.label}
              </span>
              {slaStatus && (
                <span className={`px-2 py-1 rounded text-xs ${slaStatus.color}`}>
                  {slaStatus.icon} {slaStatus.text}
                </span>
              )}
              <span className="text-slate-500 flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {formatDate(request.created_at)}
              </span>
            </div>
          </div>
        </div>
        
        {/* وصف الحالة */}
        <div className="mt-4 p-3 bg-slate-50 rounded-lg">
          <p className="text-sm text-slate-600">
            {statusConfig[request.status]?.description}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* المحتوى الرئيسي */}
        <div className="lg:col-span-2 space-y-4">
          {/* التبويبات */}
          <div className="bg-white rounded-xl shadow-sm">
            <div className="flex border-b">
              {[
                { key: 'overview', label: 'التفاصيل', icon: Eye },
                { key: 'chat', label: 'المحادثة', icon: MessageSquare, count: messages.length },
                { key: 'files', label: 'المرفقات', icon: Paperclip, count: allFiles.length },
              ].map(tab => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as any)}
                  className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 font-medium border-b-2 transition-all ${
                    activeTab === tab.key
                      ? 'text-blue-600 border-blue-600 bg-blue-50/50'
                      : 'text-slate-600 border-transparent hover:text-slate-800 hover:bg-slate-50'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  {tab.label}
                  {tab.count !== undefined && tab.count > 0 && (
                    <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                      activeTab === tab.key ? 'bg-blue-100 text-blue-600' : 'bg-slate-200 text-slate-600'
                    }`}>
                      {tab.count}
                    </span>
                  )}
                </button>
              ))}
            </div>

            <div className="p-6">
              {/* التفاصيل */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  {/* توجيه NOLEX */}
                  {request.nolex_guidance && (
                    <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200">
                      <h4 className="font-bold text-blue-800 mb-2 flex items-center gap-2">
                        <Bot className="w-5 h-5" />
                        تحليل NOLEX
                      </h4>
                      <p className="text-blue-700 text-sm">{request.nolex_guidance}</p>
                    </div>
                  )}

                  {/* وصف الطلب */}
                  <div>
                    <h4 className="font-medium text-slate-800 mb-2 flex items-center gap-2">
                      <FileText className="w-4 h-4 text-slate-400" />
                      وصف الطلب
                    </h4>
                    <div className="bg-slate-50 p-4 rounded-lg">
                      <p className="text-slate-600 whitespace-pre-wrap leading-relaxed">
                        {request.description || 'لا يوجد وصف'}
                      </p>
                    </div>
                  </div>

                  {/* معلومات إضافية */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-slate-50 p-4 rounded-lg">
                      <p className="text-xs text-slate-500 mb-1">التصنيف</p>
                      <p className="font-medium text-slate-800">{request.category?.name_ar || '-'}</p>
                    </div>
                    <div className="bg-slate-50 p-4 rounded-lg">
                      <p className="text-xs text-slate-500 mb-1">التصنيف الفرعي</p>
                      <p className="font-medium text-slate-800">{request.subcategory?.name_ar || '-'}</p>
                    </div>
                    <div className="bg-slate-50 p-4 rounded-lg">
                      <p className="text-xs text-slate-500 mb-1">تاريخ الإنشاء</p>
                      <p className="font-medium text-slate-800">{formatDateTime(request.created_at)}</p>
                    </div>
                    <div className="bg-slate-50 p-4 rounded-lg">
                      <p className="text-xs text-slate-500 mb-1">آخر تحديث</p>
                      <p className="font-medium text-slate-800">{formatDateTime(request.updated_at)}</p>
                    </div>
                  </div>

                  {/* مرفقات الطلب الأصلية */}
                  {request.attachments && request.attachments.length > 0 && (
                    <div>
                      <h4 className="font-medium text-slate-800 mb-3 flex items-center gap-2">
                        <Paperclip className="w-4 h-4 text-slate-400" />
                        المرفقات الأصلية
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {request.attachments.map((file: any, idx: number) => (
                          
                            key={idx}
                            href={file.url || file.file_url}
                            target="_blank"
                            className="flex items-center gap-2 px-3 py-2 bg-slate-100 rounded-lg hover:bg-slate-200 transition-colors"
                          >
                            <FileText className="w-4 h-4 text-blue-600" />
                            <span className="text-sm">{file.name || file.file_name || `ملف ${idx + 1}`}</span>
                            <Download className="w-4 h-4 text-slate-400" />
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* المحادثة */}
              {activeTab === 'chat' && (
                <div className="space-y-4">
                  {/* رسائل المحادثة */}
                  <div className="h-[400px] overflow-y-auto space-y-3 p-4 bg-slate-50 rounded-lg">
                    {messages.length > 0 ? (
                      <>
                        {messages.map(msg => (
                          <div
                            key={msg.id}
                            className={`flex ${msg.sender_type === 'member' ? 'justify-end' : 'justify-start'}`}
                          >
                            <div className={`max-w-[75%] ${msg.sender_type === 'member' ? 'order-1' : 'order-2'}`}>
                              <div className={`p-3 rounded-2xl ${
                                msg.sender_type === 'member'
                                  ? 'bg-blue-500 text-white rounded-br-md'
                                  : 'bg-white border shadow-sm rounded-bl-md'
                              }`}>
                                <p className="leading-relaxed">{msg.content}</p>
                                
                                {/* مرفقات الرسالة */}
                                {msg.attachments && msg.attachments.length > 0 && (
                                  <div className="mt-2 pt-2 border-t border-white/20">
                                    {msg.attachments.map((file: any, idx: number) => (
                                      
                                        key={idx}
                                        href={file.file_url}
                                        target="_blank"
                                        className={`flex items-center gap-2 text-sm ${
                                          msg.sender_type === 'member' ? 'text-blue-100 hover:text-white' : 'text-blue-600 hover:text-blue-700'
                                        }`}
                                      >
                                        <Paperclip className="w-3 h-3" />
                                        {file.file_name}
                                      </a>
                                    ))}
                                  </div>
                                )}
                              </div>
                              <p className={`text-xs mt-1 ${
                                msg.sender_type === 'member' ? 'text-left' : 'text-right'
                              } text-slate-400`}>
                                {formatTime(msg.created_at)}
                              </p>
                            </div>
                          </div>
                        ))}
                        <div ref={messagesEndRef} />
                      </>
                    ) : (
                      <div className="text-center py-12 text-slate-500">
                        <MessageSquare className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                        <p className="font-medium">لا توجد رسائل بعد</p>
                        <p className="text-sm mt-1">
                          {canSendMessage 
                            ? 'ابدأ المحادثة مع المحامي'
                            : 'ستتمكن من المحادثة عند قبول المحامي للطلب'
                          }
                        </p>
                      </div>
                    )}
                  </div>
                  
                  {/* إدخال الرسالة */}
                  {canSendMessage ? (
                    <div className="flex gap-2">
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        disabled={uploadingFile}
                        className="p-3 border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors disabled:opacity-50"
                      >
                        {uploadingFile ? (
                          <div className="w-5 h-5 border-2 border-slate-400 border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <Paperclip className="w-5 h-5 text-slate-500" />
                        )}
                      </button>
                      <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && !sendingMessage && handleSendMessage()}
                        placeholder="اكتب رسالتك هنا..."
                        className="flex-1 px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        disabled={sendingMessage}
                      />
                      <button
                        onClick={handleSendMessage}
                        disabled={sendingMessage || !newMessage.trim()}
                        className="px-5 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                      >
                        {sendingMessage ? (
                          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <>
                            <Send className="w-5 h-5" />
                            <span className="hidden sm:inline">إرسال</span>
                          </>
                        )}
                      </button>
                      <input
                        ref={fileInputRef}
                        type="file"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </div>
                  ) : (
                    <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-center">
                      <p className="text-amber-700">
                        {request.status === 'pending' || request.status === 'assigned'
                          ? '⏳ ستتمكن من المحادثة بعد قبول المحامي للطلب'
                          : '🔒 المحادثة مغلقة - الطلب منتهي'
                        }
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* المرفقات */}
              {activeTab === 'files' && (
                <div className="space-y-4">
                  {allFiles.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {allFiles.map((file: any, idx: number) => (
                        <div key={idx} className="p-4 bg-slate-50 rounded-xl flex items-center gap-4 hover:bg-slate-100 transition-colors">
                          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                            <FileText className="w-6 h-6 text-blue-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-slate-800 truncate">
                              {file.name || file.file_name || 'ملف'}
                            </p>
                            <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                              <span>{file.source}</span>
                              <span>•</span>
                              <span>{formatDate(file.uploaded_at)}</span>
                            </div>
                          </div>
                          <a 
                            href={file.url || file.file_url} 
                            target="_blank" 
                            className="p-2 hover:bg-slate-200 rounded-lg transition-colors flex-shrink-0"
                          >
                            <Download className="w-5 h-5 text-slate-600" />
                          </a>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12 text-slate-500">
                      <Paperclip className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                      <p className="font-medium">لا توجد مرفقات</p>
                      {canSendMessage && (
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          disabled={uploadingFile}
                          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                        >
                          رفع ملف
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* الشريط الجانبي */}
        <div className="space-y-4">
          {/* معلومات المحامي */}
          {lawyer ? (
            <div className="bg-white rounded-xl shadow-sm p-5">
              <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                <User className="w-5 h-5 text-blue-500" />
                المحامي المعين
              </h3>
              <div className="text-center mb-4">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-3">
                  {lawyer.full_name?.[0] || '؟'}
                </div>
                <h4 className="font-bold text-slate-800">{lawyer.full_name}</h4>
                {lawyer.city && (
                  <p className="text-sm text-slate-500">{lawyer.city}</p>
                )}
              </div>
              
              {lawyer.rating_average && (
                <div className="flex items-center justify-center gap-1 mb-4">
                  <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                  <span className="font-bold text-slate-800">{lawyer.rating_average?.toFixed(1)}</span>
                  <span className="text-sm text-slate-500">({lawyer.rating_count || 0} تقييم)</span>
                </div>
              )}
              
              <div className="space-y-3 text-sm">
                {lawyer.years_of_experience && (
                  <div className="flex items-center gap-3 text-slate-600">
                    <Timer className="w-4 h-4 text-slate-400" />
                    <span>{lawyer.years_of_experience} سنة خبرة</span>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-sm p-5">
              <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                <User className="w-5 h-5 text-blue-500" />
                المحامي
              </h3>
              <div className="text-center py-6 text-slate-500">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <User className="w-8 h-8 text-slate-300" />
                </div>
                <p className="text-sm">لم يتم تعيين محامي بعد</p>
              </div>
            </div>
          )}

          {/* ملخص الطلب */}
          <div className="bg-white rounded-xl shadow-sm p-5">
            <h3 className="font-bold text-slate-800 mb-4">📊 ملخص</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between items-center py-2 border-b border-slate-100">
                <span className="text-slate-500">الرسائل</span>
                <span className="font-medium text-slate-800">{messages.length}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-slate-100">
                <span className="text-slate-500">المرفقات</span>
                <span className="font-medium text-slate-800">{allFiles.length}</span>
              </div>
              {request.accepted_at && (
                <div className="flex justify-between items-center py-2 border-b border-slate-100">
                  <span className="text-slate-500">تاريخ القبول</span>
                  <span className="font-medium text-slate-800">{formatDate(request.accepted_at)}</span>
                </div>
              )}
              {request.completed_at && (
                <div className="flex justify-between items-center py-2">
                  <span className="text-slate-500">تاريخ الإكمال</span>
                  <span className="font-medium text-slate-800">{formatDate(request.completed_at)}</span>
                </div>
              )}
            </div>
          </div>

          {/* مساعدة */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-5 border border-blue-100">
            <h3 className="font-bold text-blue-800 mb-2">💡 تحتاج مساعدة؟</h3>
            <p className="text-sm text-blue-600 mb-3">
              يمكنك التواصل مع فريق الدعم في أي وقت
            </p>
            <button className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
              تواصل مع الدعم
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
