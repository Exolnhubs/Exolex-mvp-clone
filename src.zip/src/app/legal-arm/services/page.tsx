'use client'

import ServicesManager from '@/components/services/ServicesManager'

export default function LegalArmServicesPage() {
  return <ServicesManager providerType="legal_arm" />
}
