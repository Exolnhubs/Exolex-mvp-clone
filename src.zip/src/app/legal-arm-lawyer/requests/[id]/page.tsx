'use client'

import React, { useState, useEffect, useRef } from 'react'
import { useRouter, useParams } from 'next/navigation'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'
import toast from 'react-hot-toast'

// ═══════════════════════════════════════════════════════════════
// 📌 صفحة تفاصيل الطلب - محامي الذراع القانوني
// 📅 تاريخ الإنشاء: 4 يناير 2026
// 🎯 الغرض: عرض وإدارة تفاصيل طلب محدد
// ═══════════════════════════════════════════════════════════════
//
// ⚠️ قاعدة: لا أيقونات أو جداول ميتة - كل عنصر فيه إجراء
//
// 📋 المكونات:
// - Header: معلومات الطلب + SLA (قابل للنقر)
// - شريط الأدوات: كل زر يفتح modal أو ينفذ إجراء
// - المعلومات: كل عنصر قابل للتوسيع/التفاعل
// - التبويبات: محادثة، مشاركين، تقويم، سجل
// ═══════════════════════════════════════════════════════════════

// أنواع البيانات
interface RequestDetails {
  id: string
  request_number: string
  service_type: string
  domain: string
  category: string
  status: string
  priority: string
  is_urgent: boolean
  sla_deadline: string
  created_at: string
  started_at?: string
  completed_at?: string
  description: string
  is_package_service: boolean
  attachments: any[]
  member_code: string
  member_first_name?: string
  member_full_name?: string
  member_national_id?: string
}

interface Message {
  id: string
  sender_type: 'lawyer' | 'client'
  message: string
  attachments: any[]
  created_at: string
  is_read: boolean
}

interface Collaborator {
  id: string
  lawyer_id: string
  lawyer_name: string
  lawyer_code: string
  role: string
  status: string
  created_at: string
}

interface Appointment {
  id: string
  title: string
  description?: string
  appointment_type: string
  start_datetime: string
  end_datetime?: string
  location: string
  location_type: string
  meeting_link?: string
}

interface ActivityLog {
  id: string
  action: string
  action_details?: any
  performed_by_name: string
  created_at: string
}

// التبويبات
const bottomTabs = [
  { id: 'chat', label: 'محادثة العميل' },
  { id: 'collaborators', label: 'المشاركين' },
  { id: 'calendar', label: 'المواعيد' },
  { id: 'log', label: 'السجل' },
]

export default function RequestDetailsPage() {
  const router = useRouter()
  const params = useParams()
  const requestId = params.id as string
  
  // الحالة الأساسية
  const [isLoading, setIsLoading] = useState(true)
  const [request, setRequest] = useState<RequestDetails | null>(null)
  const [activeTab, setActiveTab] = useState('chat')
  const [lawyerId, setLawyerId] = useState<string | null>(null)
  
  // بيانات التبويبات
  const [messages, setMessages] = useState<Message[]>([])
  const [collaborators, setCollaborators] = useState<Collaborator[]>([])
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([])
  
  // الرسائل
  const [newMessage, setNewMessage] = useState('')
  const [isSending, setIsSending] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Modals
  const [showNolexModal, setShowNolexModal] = useState(false)
  const [showAppointmentModal, setShowAppointmentModal] = useState(false)
  const [showCollaboratorModal, setShowCollaboratorModal] = useState(false)
  const [showFileModal, setShowFileModal] = useState(false)
  const [showConvertModal, setShowConvertModal] = useState(false)
  const [showWakalaModal, setShowWakalaModal] = useState(false)

  // بيانات النماذج
  const [appointmentForm, setAppointmentForm] = useState({
    title: '',
    description: '',
    appointment_type: 'meeting',
    start_date: '',
    start_time: '',
    location: '',
    location_type: 'physical',
    meeting_link: '',
  })
  const [collaboratorForm, setCollaboratorForm] = useState({
    lawyer_id: '',
    role: '',
  })
  const [nolexQuery, setNolexQuery] = useState('')
  const [nolexResponse, setNolexResponse] = useState('')
  const [isNolexLoading, setIsNolexLoading] = useState(false)

  // SLA Timer
  const [slaTime, setSlaTime] = useState({ hours: 0, minutes: 0, seconds: 0, expired: false })

  // ─────────────────────────────────────────────────────────────
  // جلب البيانات
  // ─────────────────────────────────────────────────────────────
  useEffect(() => {
    const storedLawyerId = localStorage.getItem('exolex_lawyer_id')
    if (!storedLawyerId) {
      router.push('/auth/lawyer-login')
      return
    }
    setLawyerId(storedLawyerId)

    const fetchRequestDetails = async () => {
      try {
        // جلب تفاصيل الطلب
        const { data: requestData, error } = await supabase
          .from('requests')
          .select(`
            *,
            members (
              member_code,
              users (full_name, national_id)
            )
          `)
          .eq('id', requestId)
          .single()

        if (error || !requestData) {
          toast.error('لم يتم العثور على الطلب')
          router.push('/legal-arm-lawyer/requests')
          return
        }

        // تحديد ما يُعرض من معلومات العميل
        const showBasicInfo = ['in_progress', 'completed'].includes(requestData.status)
        const isCase = requestData.service_type === 'case'
        const showFullInfo = isCase && showBasicInfo

        setRequest({
          id: requestData.id,
          request_number: requestData.request_number,
          service_type: requestData.service_type,
          domain: requestData.domain,
          category: requestData.category,
          status: requestData.status,
          priority: requestData.priority,
          is_urgent: requestData.is_urgent,
          sla_deadline: requestData.sla_deadline,
          created_at: requestData.created_at,
          started_at: requestData.started_at,
          completed_at: requestData.completed_at,
          description: requestData.description,
          is_package_service: requestData.is_package_service,
          attachments: requestData.attachments || [],
          member_code: requestData.members?.member_code || 'USR-XXXXX',
          member_first_name: showBasicInfo ? requestData.members?.users?.full_name?.split(' ')[0] : undefined,
          member_full_name: showFullInfo ? requestData.members?.users?.full_name : undefined,
          member_national_id: showFullInfo ? requestData.members?.users?.national_id : undefined,
        })

        // جلب الرسائل
        const { data: messagesData } = await supabase
          .from('request_client_messages')
          .select('*')
          .eq('request_id', requestId)
          .order('created_at', { ascending: true })
        setMessages(messagesData || [])

        // جلب المشاركين
        const { data: collaboratorsData } = await supabase
          .from('request_collaborators')
          .select(`*, lawyers (full_name, lawyer_code)`)
          .eq('request_id', requestId)
          .neq('status', 'removed')
        setCollaborators(collaboratorsData?.map(c => ({
          id: c.id,
          lawyer_id: c.lawyer_id,
          lawyer_name: c.lawyers?.full_name || 'غير معروف',
          lawyer_code: c.lawyers?.lawyer_code || '',
          role: c.role,
          status: c.status,
          created_at: c.created_at,
        })) || [])

        // جلب المواعيد
        const { data: appointmentsData } = await supabase
          .from('request_appointments')
          .select('*')
          .eq('request_id', requestId)
          .order('start_datetime', { ascending: true })
        setAppointments(appointmentsData || [])

        // جلب سجل النشاط
        const { data: logsData } = await supabase
          .from('activity_logs')
          .select('*')
          .eq('entity_type', 'request')
          .eq('entity_id', requestId)
          .order('created_at', { ascending: false })
        setActivityLogs(logsData || [])

      } catch (error) {
        console.error('خطأ:', error)
        toast.error('حدث خطأ في تحميل البيانات')
      } finally {
        setIsLoading(false)
      }
    }

    fetchRequestDetails()
  }, [requestId, router])

  // SLA Timer
  useEffect(() => {
    if (!request?.sla_deadline) return

    const updateTimer = () => {
      const now = new Date()
      const deadline = new Date(request.sla_deadline)
      const diff = deadline.getTime() - now.getTime()

      if (diff <= 0) {
        setSlaTime({ hours: 0, minutes: 0, seconds: 0, expired: true })
        return
      }

      const hours = Math.floor(diff / (1000 * 60 * 60))
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((diff % (1000 * 60)) / 1000)
      setSlaTime({ hours, minutes, seconds, expired: false })
    }

    updateTimer()
    const interval = setInterval(updateTimer, 1000)
    return () => clearInterval(interval)
  }, [request?.sla_deadline])

  // ─────────────────────────────────────────────────────────────
  // دوال مساعدة
  // ─────────────────────────────────────────────────────────────
  const getServiceTypeAr = (type: string) => {
    const types: Record<string, string> = { 'consultation': 'استشارة', 'case': 'قضية', 'drafting': 'صياغة' }
    return types[type] || type
  }

  const getDomainAr = (domain: string) => {
    const domains: Record<string, string> = {
      'labor': 'عمالي', 'family': 'أسري', 'commercial': 'تجاري',
      'criminal': 'جنائي', 'real_estate': 'عقاري', 'administrative': 'إداري',
    }
    return domains[domain] || domain
  }

  const getStatusInfo = (status: string) => {
    const statuses: Record<string, { label: string; color: string; bg: string }> = {
      'new': { label: 'جديد', color: 'text-amber-700', bg: 'bg-amber-100' },
      'in_progress': { label: 'قيد المعالجة', color: 'text-blue-700', bg: 'bg-blue-100' },
      'completed': { label: 'مكتمل', color: 'text-green-700', bg: 'bg-green-100' },
      'pending': { label: 'معلق', color: 'text-orange-700', bg: 'bg-orange-100' },
    }
    return statuses[status] || { label: status, color: 'text-slate-700', bg: 'bg-slate-100' }
  }

  const formatDateTime = (dateStr: string) => {
    if (!dateStr) return '-'
    return new Date(dateStr).toLocaleString('ar-SA', {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    })
  }

  const formatTime = (dateStr: string) => {
    if (!dateStr) return '-'
    return new Date(dateStr).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })
  }

  // ─────────────────────────────────────────────────────────────
  // إرسال رسالة
  // ─────────────────────────────────────────────────────────────
  const handleSendMessage = async () => {
    if (!newMessage.trim() || isSending || !lawyerId) return

    setIsSending(true)
    try {
      const { data, error } = await supabase
        .from('request_client_messages')
        .insert({
          request_id: requestId,
          sender_type: 'lawyer',
          sender_id: lawyerId,
          message: newMessage.trim(),
        })
        .select()
        .single()

      if (error) throw error

      setMessages(prev => [...prev, {
        id: data.id,
        sender_type: 'lawyer',
        message: data.message,
        attachments: [],
        created_at: data.created_at,
        is_read: false,
      }])
      setNewMessage('')
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
      
      // تسجيل في سجل النشاط
      await supabase.from('activity_logs').insert({
        entity_type: 'request',
        entity_id: requestId,
        action: 'تم إرسال رسالة للعميل',
        performed_by: lawyerId,
      })
    } catch (error) {
      console.error('خطأ:', error)
      toast.error('حدث خطأ في إرسال الرسالة')
    } finally {
      setIsSending(false)
    }
  }

  // ─────────────────────────────────────────────────────────────
  // إضافة موعد
  // ─────────────────────────────────────────────────────────────
  const handleAddAppointment = async () => {
    if (!appointmentForm.title || !appointmentForm.start_date || !appointmentForm.start_time) {
      toast.error('يرجى ملء الحقول المطلوبة')
      return
    }

    try {
      const startDateTime = `${appointmentForm.start_date}T${appointmentForm.start_time}:00`
      
      const { data, error } = await supabase
        .from('request_appointments')
        .insert({
          request_id: requestId,
          title: appointmentForm.title,
          description: appointmentForm.description,
          appointment_type: appointmentForm.appointment_type,
          start_datetime: startDateTime,
          location: appointmentForm.location,
          location_type: appointmentForm.location_type,
          meeting_link: appointmentForm.meeting_link,
          created_by: lawyerId,
        })
        .select()
        .single()

      if (error) throw error

      setAppointments(prev => [...prev, data])
      setShowAppointmentModal(false)
      setAppointmentForm({
        title: '', description: '', appointment_type: 'meeting',
        start_date: '', start_time: '', location: '',
        location_type: 'physical', meeting_link: '',
      })
      toast.success('تم إضافة الموعد')
    } catch (error) {
      console.error('خطأ:', error)
      toast.error('حدث خطأ في إضافة الموعد')
    }
  }

  // ─────────────────────────────────────────────────────────────
  // طلب إضافة مشارك
  // ─────────────────────────────────────────────────────────────
  const handleRequestCollaborator = async () => {
    if (!collaboratorForm.lawyer_id || !collaboratorForm.role) {
      toast.error('يرجى اختيار المحامي وتحديد الدور')
      return
    }

    try {
      const { error } = await supabase
        .from('request_collaborators')
        .insert({
          request_id: requestId,
          lawyer_id: collaboratorForm.lawyer_id,
          invited_by: lawyerId,
          role: collaboratorForm.role,
          status: 'pending', // بانتظار موافقة المدير
        })

      if (error) throw error

      setShowCollaboratorModal(false)
      setCollaboratorForm({ lawyer_id: '', role: '' })
      toast.success('تم إرسال طلب إضافة المشارك للمدير')
    } catch (error) {
      console.error('خطأ:', error)
      toast.error('حدث خطأ')
    }
  }

  // ─────────────────────────────────────────────────────────────
  // مساعدة NOLEX
  // ─────────────────────────────────────────────────────────────
  const handleAskNolex = async () => {
    if (!nolexQuery.trim()) {
      toast.error('يرجى كتابة سؤالك')
      return
    }

    setIsNolexLoading(true)
    try {
      // TODO: استدعاء API الذكاء الاصطناعي
      // حالياً نعرض رسالة وهمية
      await new Promise(resolve => setTimeout(resolve, 1500))
      setNolexResponse(`بناءً على سؤالك حول "${nolexQuery}":\n\nهذه إجابة تجريبية من NOLEX. سيتم ربط النظام بالذكاء الاصطناعي لاحقاً لتقديم إجابات دقيقة ومفيدة بناءً على قاعدة المعرفة القانونية.`)
    } catch (error) {
      toast.error('حدث خطأ')
    } finally {
      setIsNolexLoading(false)
    }
  }

  // ─────────────────────────────────────────────────────────────
  // إغلاق الطلب
  // ─────────────────────────────────────────────────────────────
  const handleCompleteRequest = async () => {
    if (!confirm('هل أنت متأكد من إغلاق هذا الطلب؟')) return

    try {
      const { error } = await supabase
        .from('requests')
        .update({ status: 'completed', completed_at: new Date().toISOString() })
        .eq('id', requestId)

      if (error) throw error
      
      setRequest(prev => prev ? { ...prev, status: 'completed' } : null)
      toast.success('تم إغلاق الطلب بنجاح')
    } catch (error) {
      console.error('خطأ:', error)
      toast.error('حدث خطأ')
    }
  }

  // ─────────────────────────────────────────────────────────────
  // تحويل لقضية
  // ─────────────────────────────────────────────────────────────
  const handleConvertToCase = async () => {
    try {
      // TODO: إنشاء قضية جديدة وربطها بالطلب
      toast.success('سيتم تنفيذ هذه الخاصية قريباً')
      setShowConvertModal(false)
    } catch (error) {
      toast.error('حدث خطأ')
    }
  }

  // ─────────────────────────────────────────────────────────────
  // شاشة التحميل
  // ─────────────────────────────────────────────────────────────
  if (isLoading || !request) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-500">جاري تحميل الطلب...</p>
        </div>
      </div>
    )
  }

  const statusInfo = getStatusInfo(request.status)

  return (
    <div className="space-y-4">
      
      {/* ═══════════════════════════════════════════════════════════ */}
      {/* Header - قابل للتفاعل */}
      {/* ═══════════════════════════════════════════════════════════ */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          {/* رجوع + معلومات */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push('/legal-arm-lawyer/requests')}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              title="رجوع للقائمة"
            >
              <span className="text-xl">→</span>
            </button>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                {request.is_urgent && (
                  <span className="px-2 py-1 bg-red-500 text-white rounded-full text-xs font-bold">عاجل</span>
                )}
                <h1 className="text-xl font-bold text-slate-800">{request.request_number}</h1>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusInfo.bg} ${statusInfo.color}`}>
                  {statusInfo.label}
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-500 mt-1 flex-wrap">
                <span className="hover:text-amber-600 transition-colors">
                  {getDomainAr(request.domain)}
                </span>
                <span>•</span>
                <span>{request.category}</span>
                <span>•</span>
                <span>{getServiceTypeAr(request.service_type)}</span>
              </div>
            </div>
          </div>

          {/* SLA Timer - قابل للنقر */}
          <button
            onClick={() => toast(`الموعد النهائي: ${formatDateTime(request.sla_deadline)}`)}
            className={`text-center p-3 rounded-xl transition-colors ${
              slaTime.expired ? 'bg-red-50 hover:bg-red-100' : 'bg-slate-50 hover:bg-slate-100'
            }`}
          >
            <p className="text-xs text-slate-500 mb-1">SLA</p>
            <p className={`text-2xl font-mono font-bold ${slaTime.expired ? 'text-red-600' : slaTime.hours < 6 ? 'text-orange-600' : 'text-green-600'}`}>
              {slaTime.expired 
                ? 'منتهي' 
                : `${String(slaTime.hours).padStart(2, '0')}:${String(slaTime.minutes).padStart(2, '0')}:${String(slaTime.seconds).padStart(2, '0')}`
              }
            </p>
          </button>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* شريط الأدوات - كل زر يفتح modal */}
      {/* ═══════════════════════════════════════════════════════════ */}
      {request.status !== 'completed' && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-3">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setShowNolexModal(true)}
              className="px-4 py-2 bg-purple-100 hover:bg-purple-200 text-purple-700 rounded-xl text-sm font-medium transition-colors"
            >
              مساعدة NOLEX
            </button>
            <button
              onClick={() => setShowAppointmentModal(true)}
              className="px-4 py-2 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded-xl text-sm font-medium transition-colors"
            >
              إضافة موعد
            </button>
            {request.service_type === 'consultation' && (
              <button
                onClick={() => setShowConvertModal(true)}
                className="px-4 py-2 bg-amber-100 hover:bg-amber-200 text-amber-700 rounded-xl text-sm font-medium transition-colors"
              >
                تحويل لقضية
              </button>
            )}
            {request.service_type === 'case' && (
              <button
                onClick={() => setShowWakalaModal(true)}
                className="px-4 py-2 bg-green-100 hover:bg-green-200 text-green-700 rounded-xl text-sm font-medium transition-colors"
              >
                نموذج وكالة
              </button>
            )}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-sm font-medium transition-colors"
            >
              إضافة ملف
            </button>
            <input type="file" ref={fileInputRef} className="hidden" onChange={() => toast('سيتم تنفيذ رفع الملفات قريباً')} />
            <button
              onClick={() => setShowCollaboratorModal(true)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-sm font-medium transition-colors"
            >
              إضافة مشارك
            </button>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* معلومات الطلب + العميل */}
      {/* ═══════════════════════════════════════════════════════════ */}
      <div className="grid lg:grid-cols-2 gap-4">
        {/* معلومات الطلب */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4">
          <h3 className="font-semibold text-slate-800 mb-4">معلومات الطلب</h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between items-center p-2 hover:bg-slate-50 rounded-lg cursor-pointer" onClick={() => toast(`نوع الطلب: ${getServiceTypeAr(request.service_type)}`)}>
              <span className="text-slate-500">نوع الطلب</span>
              <span className="font-medium">{getServiceTypeAr(request.service_type)}</span>
            </div>
            <div className="flex justify-between items-center p-2 hover:bg-slate-50 rounded-lg cursor-pointer" onClick={() => toast(`المجال: ${getDomainAr(request.domain)}`)}>
              <span className="text-slate-500">المجال</span>
              <span className="font-medium">{getDomainAr(request.domain)}</span>
            </div>
            <div className="flex justify-between items-center p-2 hover:bg-slate-50 rounded-lg">
              <span className="text-slate-500">الفئة</span>
              <span className="font-medium">{request.category}</span>
            </div>
            <div className="flex justify-between items-center p-2 hover:bg-slate-50 rounded-lg">
              <span className="text-slate-500">الأولوية</span>
              <span className={`font-medium ${request.is_urgent ? 'text-red-600' : ''}`}>
                {request.is_urgent ? 'عاجل' : 'عادي'}
              </span>
            </div>
            <div className="flex justify-between items-center p-2 hover:bg-slate-50 rounded-lg">
              <span className="text-slate-500">تاريخ الإنشاء</span>
              <span className="font-medium">{formatDateTime(request.created_at)}</span>
            </div>
            <div className="pt-3 border-t border-slate-100">
              <p className="text-slate-500 mb-2">الوصف:</p>
              <p className="text-slate-700 bg-slate-50 p-3 rounded-lg">{request.description || 'لا يوجد وصف'}</p>
            </div>
          </div>
        </div>

        {/* معلومات العميل */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4">
          <h3 className="font-semibold text-slate-800 mb-4">معلومات العميل</h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between items-center p-2 bg-slate-50 rounded-lg">
              <span className="text-slate-500">رمز العميل</span>
              <span className="font-mono font-medium">{request.member_code}</span>
            </div>
            
            {request.member_first_name && (
              <div className="flex justify-between items-center p-2 bg-slate-50 rounded-lg">
                <span className="text-slate-500">الاسم الأول</span>
                <span className="font-medium">{request.member_first_name}</span>
              </div>
            )}
            
            {request.member_full_name && (
              <div className="flex justify-between items-center p-2 bg-slate-50 rounded-lg">
                <span className="text-slate-500">الاسم الكامل</span>
                <span className="font-medium">{request.member_full_name}</span>
              </div>
            )}
            
            {request.member_national_id && (
              <div className="flex justify-between items-center p-2 bg-slate-50 rounded-lg">
                <span className="text-slate-500">رقم الهوية</span>
                <span className="font-mono font-medium">{request.member_national_id}</span>
              </div>
            )}

            {!request.member_first_name && (
              <div className="p-4 bg-amber-50 rounded-xl">
                <p className="text-sm text-amber-700">
                  معلومات العميل مخفية حتى مباشرة الطلب
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* المرفقات - قابلة للنقر والتحميل */}
      {/* ═══════════════════════════════════════════════════════════ */}
      {request.attachments && request.attachments.length > 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4">
          <h3 className="font-semibold text-slate-800 mb-4">المرفقات ({request.attachments.length})</h3>
          <div className="flex flex-wrap gap-2">
            {request.attachments.map((file: any, index: number) => (
              <a
                key={index}
                href={file.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
              >
                <span className="text-sm font-medium">{file.name}</span>
                <span className="text-xs text-slate-500">تحميل</span>
              </a>
            ))}
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* التبويبات السفلية */}
      {/* ═══════════════════════════════════════════════════════════ */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200">
        {/* رأس التبويبات */}
        <div className="border-b border-slate-200 p-2">
          <div className="flex gap-2">
            {bottomTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-xl font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-amber-500 text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {tab.label}
                {tab.id === 'chat' && messages.length > 0 && (
                  <span className="mr-2 px-2 py-0.5 bg-white/20 rounded-full text-xs">{messages.length}</span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* محتوى التبويب */}
        <div className="p-4 min-h-[300px]">
          
          {/* تبويب المحادثة */}
          {activeTab === 'chat' && (
            <div className="space-y-4">
              <div className="space-y-3 max-h-[400px] overflow-y-auto">
                {messages.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-slate-400 mb-4">لا توجد رسائل بعد</p>
                    <p className="text-sm text-slate-500">ابدأ محادثة مع العميل</p>
                  </div>
                ) : (
                  messages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.sender_type === 'lawyer' ? 'justify-start' : 'justify-end'}`}>
                      <div className={`max-w-[70%] rounded-2xl p-3 ${
                        msg.sender_type === 'lawyer' ? 'bg-amber-100' : 'bg-slate-100'
                      }`}>
                        <p className="text-xs text-slate-500 mb-1">
                          {msg.sender_type === 'lawyer' ? 'أنت' : request.member_code} • {formatTime(msg.created_at)}
                        </p>
                        <p className="text-sm">{msg.message}</p>
                      </div>
                    </div>
                  ))
                )}
                <div ref={messagesEndRef} />
              </div>

              {request.status !== 'completed' && (
                <div className="flex gap-2 pt-4 border-t border-slate-200">
                  <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="اكتب رسالتك..."
                    className="flex-1 px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                  <button
                    onClick={handleSendMessage}
                    disabled={isSending || !newMessage.trim()}
                    className="px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl font-medium disabled:opacity-50 transition-colors"
                  >
                    {isSending ? '...' : 'إرسال'}
                  </button>
                </div>
              )}
            </div>
          )}

          {/* تبويب المشاركين */}
          {activeTab === 'collaborators' && (
            <div className="space-y-3">
              {/* المحامي الأساسي (أنت) */}
              <div className="p-4 bg-amber-50 rounded-xl border border-amber-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-slate-800">أنت (المحامي الأساسي)</p>
                    <p className="text-sm text-slate-500">مسؤول الطلب</p>
                  </div>
                </div>
              </div>

              {collaborators.map((collab) => (
                <div key={collab.id} className="p-4 bg-slate-50 rounded-xl flex items-center justify-between">
                  <div>
                    <p className="font-medium text-slate-800">{collab.lawyer_name}</p>
                    <p className="text-sm text-slate-500">{collab.role}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      collab.status === 'approved' ? 'bg-green-100 text-green-700' :
                      collab.status === 'pending' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {collab.status === 'approved' ? 'موافق عليه' : collab.status === 'pending' ? 'بانتظار الموافقة' : collab.status}
                    </span>
                    {collab.status === 'approved' && (
                      <button className="px-3 py-1 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded-lg text-sm transition-colors">
                        محادثة
                      </button>
                    )}
                  </div>
                </div>
              ))}

              {request.status !== 'completed' && (
                <button
                  onClick={() => setShowCollaboratorModal(true)}
                  className="w-full py-3 border-2 border-dashed border-slate-300 hover:border-amber-400 text-slate-500 hover:text-amber-600 rounded-xl transition-colors"
                >
                  + طلب إضافة مشارك
                </button>
              )}
            </div>
          )}

          {/* تبويب المواعيد */}
          {activeTab === 'calendar' && (
            <div className="space-y-3">
              {appointments.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-slate-400 mb-4">لا توجد مواعيد</p>
                </div>
              ) : (
                appointments.map((apt) => (
                  <div key={apt.id} className="p-4 bg-slate-50 rounded-xl flex items-center justify-between hover:bg-slate-100 transition-colors cursor-pointer">
                    <div>
                      <p className="font-medium text-slate-800">{apt.title}</p>
                      <p className="text-sm text-slate-500">{formatDateTime(apt.start_datetime)}</p>
                      <p className="text-xs text-slate-400">{apt.location}</p>
                    </div>
                    <div className="flex gap-2">
                      {apt.meeting_link && (
                        <a href={apt.meeting_link} target="_blank" className="px-3 py-1 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded-lg text-sm transition-colors">
                          رابط الاجتماع
                        </a>
                      )}
                      <button className="px-3 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-sm transition-colors">
                        تعديل
                      </button>
                    </div>
                  </div>
                ))
              )}

              {request.status !== 'completed' && (
                <button
                  onClick={() => setShowAppointmentModal(true)}
                  className="w-full py-3 border-2 border-dashed border-slate-300 hover:border-amber-400 text-slate-500 hover:text-amber-600 rounded-xl transition-colors"
                >
                  + إضافة موعد
                </button>
              )}
            </div>
          )}

          {/* تبويب السجل */}
          {activeTab === 'log' && (
            <div className="space-y-2">
              {activityLogs.length === 0 ? (
                <p className="text-center text-slate-400 py-8">لا توجد سجلات</p>
              ) : (
                activityLogs.map((log) => (
                  <div key={log.id} className="flex items-start gap-3 py-2 border-b border-slate-100 last:border-0">
                    <span className="text-slate-300">●</span>
                    <div className="flex-1">
                      <p className="text-sm text-slate-700">{log.action}</p>
                      <p className="text-xs text-slate-400">{formatDateTime(log.created_at)}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* أزرار الإجراءات */}
      {/* ═══════════════════════════════════════════════════════════ */}
      {request.status !== 'completed' && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4">
          <div className="flex flex-wrap gap-3 justify-end">
            {request.service_type === 'consultation' && (
              <button
                onClick={() => setShowConvertModal(true)}
                className="px-6 py-2.5 bg-purple-500 hover:bg-purple-600 text-white rounded-xl font-medium transition-colors"
              >
                تحويل لقضية
              </button>
            )}
            <button
              onClick={handleCompleteRequest}
              className="px-6 py-2.5 bg-green-500 hover:bg-green-600 text-white rounded-xl font-medium transition-colors"
            >
              إغلاق الطلب
            </button>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* Modal: مساعدة NOLEX */}
      {/* ═══════════════════════════════════════════════════════════ */}
      {showNolexModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg">
            <div className="border-b border-slate-200 px-6 py-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-800">مساعدة NOLEX</h2>
              <button onClick={() => setShowNolexModal(false)} className="p-2 hover:bg-slate-100 rounded-lg">✕</button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">اكتب سؤالك</label>
                <textarea
                  value={nolexQuery}
                  onChange={(e) => setNolexQuery(e.target.value)}
                  rows={3}
                  className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-purple-500 outline-none resize-none"
                  placeholder="مثال: ما هي مدة التقادم في قضايا الفصل التعسفي؟"
                />
              </div>
              <button
                onClick={handleAskNolex}
                disabled={isNolexLoading || !nolexQuery.trim()}
                className="w-full py-3 bg-purple-500 hover:bg-purple-600 text-white rounded-xl font-medium disabled:opacity-50 transition-colors"
              >
                {isNolexLoading ? 'جاري البحث...' : 'اسأل NOLEX'}
              </button>
              {nolexResponse && (
                <div className="p-4 bg-purple-50 rounded-xl">
                  <p className="text-sm text-purple-800 whitespace-pre-wrap">{nolexResponse}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* Modal: إضافة موعد */}
      {/* ═══════════════════════════════════════════════════════════ */}
      {showAppointmentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg">
            <div className="border-b border-slate-200 px-6 py-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-800">إضافة موعد</h2>
              <button onClick={() => setShowAppointmentModal(false)} className="p-2 hover:bg-slate-100 rounded-lg">✕</button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">العنوان *</label>
                <input
                  type="text"
                  value={appointmentForm.title}
                  onChange={(e) => setAppointmentForm(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  placeholder="مثال: جلسة محكمة"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">التاريخ *</label>
                  <input
                    type="date"
                    value={appointmentForm.start_date}
                    onChange={(e) => setAppointmentForm(prev => ({ ...prev, start_date: e.target.value }))}
                    className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">الوقت *</label>
                  <input
                    type="time"
                    value={appointmentForm.start_time}
                    onChange={(e) => setAppointmentForm(prev => ({ ...prev, start_time: e.target.value }))}
                    className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">نوع الموعد</label>
                <select
                  value={appointmentForm.appointment_type}
                  onChange={(e) => setAppointmentForm(prev => ({ ...prev, appointment_type: e.target.value }))}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none bg-white"
                >
                  <option value="meeting">اجتماع</option>
                  <option value="court_session">جلسة محكمة</option>
                  <option value="consultation">استشارة</option>
                  <option value="other">أخرى</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">المكان</label>
                <input
                  type="text"
                  value={appointmentForm.location}
                  onChange={(e) => setAppointmentForm(prev => ({ ...prev, location: e.target.value }))}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  placeholder="مثال: محكمة العمل - الرياض"
                />
              </div>
            </div>
            <div className="border-t border-slate-200 px-6 py-4 flex gap-3">
              <button
                onClick={() => setShowAppointmentModal(false)}
                className="flex-1 py-3 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl font-medium transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={handleAddAppointment}
                className="flex-1 py-3 bg-amber-500 hover:bg-amber-600 text-white rounded-xl font-medium transition-colors"
              >
                إضافة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* Modal: إضافة مشارك */}
      {/* ═══════════════════════════════════════════════════════════ */}
      {showCollaboratorModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg">
            <div className="border-b border-slate-200 px-6 py-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-800">طلب إضافة مشارك</h2>
              <button onClick={() => setShowCollaboratorModal(false)} className="p-2 hover:bg-slate-100 rounded-lg">✕</button>
            </div>
            <div className="p-6 space-y-4">
              <div className="p-3 bg-amber-50 rounded-xl">
                <p className="text-sm text-amber-700">سيتم إرسال الطلب للمدير للموافقة</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">اختر المحامي *</label>
                <select
                  value={collaboratorForm.lawyer_id}
                  onChange={(e) => setCollaboratorForm(prev => ({ ...prev, lawyer_id: e.target.value }))}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none bg-white"
                >
                  <option value="">اختر...</option>
                  {/* TODO: جلب قائمة المحامين من قاعدة البيانات */}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">الدور *</label>
                <input
                  type="text"
                  value={collaboratorForm.role}
                  onChange={(e) => setCollaboratorForm(prev => ({ ...prev, role: e.target.value }))}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  placeholder="مثال: مراجعة المستندات، حضور الجلسات"
                />
              </div>
            </div>
            <div className="border-t border-slate-200 px-6 py-4 flex gap-3">
              <button
                onClick={() => setShowCollaboratorModal(false)}
                className="flex-1 py-3 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl font-medium transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={handleRequestCollaborator}
                className="flex-1 py-3 bg-amber-500 hover:bg-amber-600 text-white rounded-xl font-medium transition-colors"
              >
                إرسال الطلب
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  )
}
