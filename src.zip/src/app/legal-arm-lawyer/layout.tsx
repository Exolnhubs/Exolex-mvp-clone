'use client'

import { useState, useEffect } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'

// ═══════════════════════════════════════════════════════════════
// 📌 Layout بوابة محامي الذراع القانوني
// 📅 تاريخ الإنشاء: 4 يناير 2026
// 🎯 الغرض: Sidebar للشاشات الكبيرة + Bottom Nav للجوال
// ═══════════════════════════════════════════════════════════════
//
// 📦 يتطلب في localStorage:
// - exolex_lawyer_id: معرف المحامي
// - exolex_lawyer_code: كود المحامي (LARM-XXX-YY)
// - exolex_legal_arm_id: معرف الذراع القانوني
// ═══════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────────
// قائمة التنقل
// ─────────────────────────────────────────────────────────────
const navItems = [
  { 
    href: '/legal-arm-lawyer/dashboard', 
    label: 'الرئيسية', 
    icon: '🏠',
    activeIcon: '🏠'
  },
  { 
    href: '/legal-arm-lawyer/requests', 
    label: 'الطلبات', 
    icon: '📋',
    activeIcon: '📋'
  },
  { 
    href: '/legal-arm-lawyer/my-quotes', label: 'عروضي', icon: '💰' 
  },
  { 
    href: '/legal-arm-lawyer/cases', 
    label: 'القضايا', 
    icon: '⚖️',
    activeIcon: '⚖️'
  },
  { 
    href: '/legal-arm-lawyer/calendar', 
    label: 'التقويم', 
    icon: '📅',
    activeIcon: '📅'
  },
  { 
    href: '/legal-arm-lawyer/profile', 
    label: 'ملفي', 
    icon: '👤',
    activeIcon: '👤'
  },
  { 
    href: '/legal-arm-lawyer/settings', 
    label: 'الإعدادات', 
    icon: '⚙️',
    activeIcon: '⚙️'
  },
]

// ─────────────────────────────────────────────────────────────
// أنواع البيانات
// ─────────────────────────────────────────────────────────────
interface LawyerInfo {
  id: string
  full_name: string
  lawyer_code: string
}

interface LegalArmInfo {
  id: string
  name_ar: string
  logo_url?: string
}

export default function LegalArmLawyerLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const pathname = usePathname()
  
  const [isLoading, setIsLoading] = useState(true)
  const [lawyerInfo, setLawyerInfo] = useState<LawyerInfo | null>(null)
  const [legalArmInfo, setLegalArmInfo] = useState<LegalArmInfo | null>(null)
  const [unreadNotifications, setUnreadNotifications] = useState(0)
  const [sidebarOpen, setSidebarOpen] = useState(false)

  // ─────────────────────────────────────────────────────────────
  // التحقق من تسجيل الدخول وجلب البيانات
  // ─────────────────────────────────────────────────────────────
  useEffect(() => {
    const checkAuthAndFetchData = async () => {
      // التحقق من وجود المعرفات في localStorage
      const lawyerId = localStorage.getItem('exolex_lawyer_id')
      const legalArmId = localStorage.getItem('exolex_legal_arm_id')

      // إذا لم يوجد أي منهما → توجيه لصفحة الدخول
      if (!lawyerId || !legalArmId) {
        router.push('/auth/lawyer-login')
        return
      }

      try {
        // جلب بيانات المحامي
        const { data: lawyer, error: lawyerError } = await supabase
          .from('lawyers')
          .select('id, full_name, lawyer_code, status')
          .eq('id', lawyerId)
          .single()

        if (lawyerError || !lawyer) {
          console.error('خطأ في جلب بيانات المحامي:', lawyerError)
          localStorage.clear()
          router.push('/auth/lawyer-login')
          return
        }

        // التحقق من حالة المحامي
        if (lawyer.status !== 'active') {
          localStorage.clear()
          router.push('/auth/lawyer-login')
          return
        }

        setLawyerInfo({
          id: lawyer.id,
          full_name: lawyer.full_name,
          lawyer_code: lawyer.lawyer_code
        })

        // جلب بيانات الذراع القانوني
        const { data: legalArm, error: armError } = await supabase
          .from('legal_arms')
          .select('id, name_ar, logo_url')
          .eq('id', legalArmId)
          .single()

        if (armError || !legalArm) {
          console.error('خطأ في جلب بيانات الذراع:', armError)
        } else {
          setLegalArmInfo({
            id: legalArm.id,
            name_ar: legalArm.name_ar,
            logo_url: legalArm.logo_url
          })
        }

        // جلب عدد الإشعارات غير المقروءة
        const { count } = await supabase
          .from('notifications')
          .select('*', { count: 'exact', head: true })
          .eq('recipient_id', lawyerId)
          .eq('is_read', false)

        setUnreadNotifications(count || 0)

      } catch (error) {
        console.error('خطأ:', error)
      } finally {
        setIsLoading(false)
      }
    }

    checkAuthAndFetchData()
  }, [router])

  // ─────────────────────────────────────────────────────────────
  // تسجيل الخروج
  // ─────────────────────────────────────────────────────────────
  const handleLogout = () => {
    localStorage.removeItem('exolex_lawyer_id')
    localStorage.removeItem('exolex_lawyer_code')
    localStorage.removeItem('exolex_legal_arm_id')
    router.push('/auth/lawyer-login')
  }

  // ─────────────────────────────────────────────────────────────
  // شاشة التحميل
  // ─────────────────────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50" dir="rtl">
      
      {/* ═══════════════════════════════════════════════════════════ */}
      {/* Sidebar - للشاشات الكبيرة */}
      {/* ═══════════════════════════════════════════════════════════ */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-white border-l border-slate-200 shadow-sm">
        
        {/* شعار الذراع القانوني */}
        <div className="p-6 border-b border-slate-200">
          <div className="flex items-center gap-3">
            {legalArmInfo?.logo_url ? (
              <img 
                src={legalArmInfo.logo_url} 
                alt="شعار" 
                className="w-12 h-12 rounded-xl object-cover"
              />
            ) : (
              <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl flex items-center justify-center">
                <span className="text-2xl">⚖️</span>
              </div>
            )}
            <div>
              <h1 className="font-bold text-slate-800 text-sm">
                {legalArmInfo?.name_ar || 'الذراع القانوني'}
              </h1>
              <p className="text-xs text-slate-500">بوابة المحامي</p>
            </div>
          </div>
        </div>

        {/* معلومات المحامي */}
        <div className="p-4 border-b border-slate-200 bg-slate-50">
          <p className="text-sm text-slate-600">مرحباً،</p>
          <p className="font-semibold text-slate-800">{lawyerInfo?.full_name}</p>
          <p className="text-xs text-slate-500 mt-1">{lawyerInfo?.lawyer_code}</p>
        </div>

        {/* قائمة التنقل */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = pathname === item.href || pathname?.startsWith(item.href + '/')
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                  isActive
                    ? 'bg-amber-50 text-amber-700 font-medium'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <span className="text-xl">{isActive ? item.activeIcon : item.icon}</span>
                <span>{item.label}</span>
              </Link>
            )
          })}
        </nav>

        {/* زر تسجيل الخروج */}
        <div className="p-4 border-t border-slate-200">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 w-full px-4 py-3 text-red-600 hover:bg-red-50 rounded-xl transition-all duration-200"
          >
            <span className="text-xl">🚪</span>
            <span>تسجيل الخروج</span>
          </button>
        </div>
      </aside>

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* المحتوى الرئيسي */}
      {/* ═══════════════════════════════════════════════════════════ */}
      <main className="lg:mr-64">
        
        {/* Header - للجوال والشاشات الكبيرة */}
        <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm">
          <div className="flex items-center justify-between px-4 py-3 lg:px-6">
            
            {/* زر القائمة للجوال */}
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>

            {/* شعار للجوال */}
            <div className="lg:hidden flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg flex items-center justify-center">
                <span className="text-lg">⚖️</span>
              </div>
              <span className="font-bold text-slate-800">ExoLex</span>
            </div>

            {/* عنوان الصفحة - للشاشات الكبيرة */}
            <div className="hidden lg:block">
              <h2 className="text-lg font-semibold text-slate-800">
                {navItems.find(item => pathname === item.href || pathname?.startsWith(item.href + '/'))?.label || 'لوحة التحكم'}
              </h2>
            </div>

            {/* الإشعارات */}
            <Link
              href="/legal-arm-lawyer/notifications"
              className="relative p-2 text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              <span className="text-xl">🔔</span>
              {unreadNotifications > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                  {unreadNotifications > 9 ? '9+' : unreadNotifications}
                </span>
              )}
            </Link>
          </div>
        </header>

        {/* المحتوى */}
        <div className="p-4 lg:p-6 pb-24 lg:pb-6">
          {children}
        </div>
      </main>

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* Mobile Sidebar Overlay */}
      {/* ═══════════════════════════════════════════════════════════ */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          {/* خلفية معتمة */}
          <div 
            className="absolute inset-0 bg-black/50"
            onClick={() => setSidebarOpen(false)}
          ></div>
          
          {/* القائمة الجانبية */}
          <div className="absolute right-0 top-0 bottom-0 w-72 bg-white shadow-xl">
            {/* شعار الذراع */}
            <div className="p-6 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl flex items-center justify-center">
                  <span className="text-xl">⚖️</span>
                </div>
                <div>
                  <h1 className="font-bold text-slate-800 text-sm">
                    {legalArmInfo?.name_ar || 'الذراع القانوني'}
                  </h1>
                </div>
              </div>
              <button
                onClick={() => setSidebarOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            {/* معلومات المحامي */}
            <div className="p-4 border-b border-slate-200 bg-slate-50">
              <p className="text-sm text-slate-600">مرحباً،</p>
              <p className="font-semibold text-slate-800">{lawyerInfo?.full_name}</p>
            </div>

            {/* قائمة التنقل */}
            <nav className="p-4 space-y-1">
              {navItems.map((item) => {
                const isActive = pathname === item.href
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setSidebarOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                      isActive
                        ? 'bg-amber-50 text-amber-700 font-medium'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <span className="text-xl">{item.icon}</span>
                    <span>{item.label}</span>
                  </Link>
                )
              })}
            </nav>

            {/* تسجيل الخروج */}
            <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-slate-200">
              <button
                onClick={handleLogout}
                className="flex items-center gap-3 w-full px-4 py-3 text-red-600 hover:bg-red-50 rounded-xl"
              >
                <span className="text-xl">🚪</span>
                <span>تسجيل الخروج</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* Bottom Navigation - للجوال فقط */}
      {/* ═══════════════════════════════════════════════════════════ */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-lg z-40">
        <div className="flex justify-around items-center py-2">
          {navItems.slice(0, 5).map((item) => {
            const isActive = pathname === item.href || pathname?.startsWith(item.href + '/')
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex flex-col items-center py-2 px-3 rounded-lg transition-all ${
                  isActive
                    ? 'text-amber-600'
                    : 'text-slate-500'
                }`}
              >
                <span className="text-xl mb-1">{item.icon}</span>
                <span className="text-[10px]">{item.label}</span>
              </Link>
            )
          })}
        </div>
      </nav>
    </div>
  )
}
