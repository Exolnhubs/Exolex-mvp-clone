'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'

// ═══════════════════════════════════════════════════════════════
// 📌 لوحة تحكم محامي الذراع القانوني
// 📅 تاريخ الإنشاء: 4 يناير 2026
// 🎯 الغرض: عرض إحصائيات وملخص نشاط المحامي
// ═══════════════════════════════════════════════════════════════
//
// 📋 العناصر المعروضة:
// - إحصائيات سريعة (قابلة للنقر)
// - الجلسات القادمة
// - آخر الإشعارات
// - الطلبات الحالية (5 صفوف)
// - القضايا النشطة (5 صفوف)
// ═══════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────────
// أنواع البيانات
// ─────────────────────────────────────────────────────────────
interface Stats {
  newRequests: number
  newRequestsChange: number
  inProgress: number
  inProgressChange: number
  overdue: number
  overdueChange: number
  activeCases: number
  activeCasesChange: number
  avgRating: number
  totalRatings: number
}

interface Request {
  id: string
  request_number: string
  service_type: string
  domain: string
  status: string
  sla_deadline: string
  created_at: string
}

interface Case {
  id: string
  case_number: string
  client_name: string
  court_name: string
  next_session: string
  status: string
}

interface Session {
  id: string
  title: string
  date: string
  time: string
  type: string
}

interface Notification {
  id: string
  title: string
  created_at: string
  type: string
}

export default function LegalArmLawyerDashboard() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  
  // البيانات
  const [stats, setStats] = useState<Stats>({
    newRequests: 0,
    newRequestsChange: 0,
    inProgress: 0,
    inProgressChange: 0,
    overdue: 0,
    overdueChange: 0,
    activeCases: 0,
    activeCasesChange: 0,
    avgRating: 0,
    totalRatings: 0
  })
  const [requests, setRequests] = useState<Request[]>([])
  const [cases, setCases] = useState<Case[]>([])
  const [sessions, setSessions] = useState<Session[]>([])
  const [notifications, setNotifications] = useState<Notification[]>([])

  // ─────────────────────────────────────────────────────────────
  // جلب البيانات
  // ─────────────────────────────────────────────────────────────
  useEffect(() => {
    const fetchDashboardData = async () => {
      const lawyerId = localStorage.getItem('exolex_lawyer_id')
      
      if (!lawyerId) {
        router.push('/auth/lawyer-login')
        return
      }

      try {
        // ═══════════════════════════════════════════════════════
        // جلب الإحصائيات
        // ═══════════════════════════════════════════════════════
        
        // طلبات جديدة
        const { count: newCount } = await supabase
          .from('requests')
          .select('*', { count: 'exact', head: true })
          .eq('assigned_lawyer_id', lawyerId)
          .eq('status', 'new')

        // طلبات قيد التنفيذ
        const { count: inProgressCount } = await supabase
          .from('requests')
          .select('*', { count: 'exact', head: true })
          .eq('assigned_lawyer_id', lawyerId)
          .eq('status', 'in_progress')

        // طلبات متأخرة (تجاوزت SLA)
        const { count: overdueCount } = await supabase
          .from('requests')
          .select('*', { count: 'exact', head: true })
          .eq('assigned_lawyer_id', lawyerId)
          .in('status', ['new', 'in_progress'])
          .lt('sla_deadline', new Date().toISOString())

        // قضايا نشطة
        const { count: casesCount } = await supabase
          .from('case_management')
          .select('*', { count: 'exact', head: true })
          .eq('assigned_lawyer_id', lawyerId)
          .eq('status', 'active')

        // متوسط التقييم
        const { data: lawyerData } = await supabase
          .from('lawyers')
          .select('avg_rating, rating_count')
          .eq('id', lawyerId)
          .single()

        setStats({
          newRequests: newCount || 0,
          newRequestsChange: 2, // TODO: حساب حقيقي
          inProgress: inProgressCount || 0,
          inProgressChange: 1,
          overdue: overdueCount || 0,
          overdueChange: -1,
          activeCases: casesCount || 0,
          activeCasesChange: 0,
          avgRating: lawyerData?.avg_rating || 0,
          totalRatings: lawyerData?.rating_count || 0
        })

        // ═══════════════════════════════════════════════════════
        // جلب آخر 5 طلبات
        // ═══════════════════════════════════════════════════════
        const { data: requestsData } = await supabase
          .from('requests')
          .select('id, request_number, service_type, domain, status, sla_deadline, created_at')
          .eq('assigned_lawyer_id', lawyerId)
          .in('status', ['new', 'in_progress'])
          .order('created_at', { ascending: false })
          .limit(5)

        setRequests(requestsData || [])

        // ═══════════════════════════════════════════════════════
        // جلب آخر 5 قضايا نشطة
        // ═══════════════════════════════════════════════════════
        const { data: casesData } = await supabase
          .from('case_management')
          .select('id, case_number, client_name, court_name, next_session_date, status')
          .eq('assigned_lawyer_id', lawyerId)
          .eq('status', 'active')
          .order('next_session_date', { ascending: true })
          .limit(5)

        setCases(casesData?.map(c => ({
          id: c.id,
          case_number: c.case_number,
          client_name: c.client_name,
          court_name: c.court_name,
          next_session: c.next_session_date,
          status: c.status
        })) || [])

        // ═══════════════════════════════════════════════════════
        // جلب الجلسات القادمة (7 أيام)
        // ═══════════════════════════════════════════════════════
        const nextWeek = new Date()
        nextWeek.setDate(nextWeek.getDate() + 7)
        
        const { data: sessionsData } = await supabase
          .from('case_sessions')
          .select('id, session_date, session_time, session_type, case_management(case_number)')
          .eq('lawyer_id', lawyerId)
          .gte('session_date', new Date().toISOString().split('T')[0])
          .lte('session_date', nextWeek.toISOString().split('T')[0])
          .order('session_date', { ascending: true })
          .limit(5)

        setSessions(sessionsData?.map(s => ({
          id: s.id,
          title: `قضية ${s.case_management?.case_number || ''}`,
          date: s.session_date,
          time: s.session_time,
          type: s.session_type
        })) || [])

        // ═══════════════════════════════════════════════════════
        // جلب آخر الإشعارات
        // ═══════════════════════════════════════════════════════
        const { data: notificationsData } = await supabase
          .from('notifications')
          .select('id, title, created_at, type')
          .eq('recipient_id', lawyerId)
          .order('created_at', { ascending: false })
          .limit(5)

        setNotifications(notificationsData || [])

      } catch (error) {
        console.error('خطأ في جلب البيانات:', error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchDashboardData()
  }, [router])

  // ─────────────────────────────────────────────────────────────
  // دوال مساعدة
  // ─────────────────────────────────────────────────────────────
  
  // تنسيق التاريخ
  const formatDate = (dateStr: string) => {
    if (!dateStr) return '-'
    const date = new Date(dateStr)
    const today = new Date()
    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)
    
    if (date.toDateString() === today.toDateString()) return 'اليوم'
    if (date.toDateString() === tomorrow.toDateString()) return 'غداً'
    
    return date.toLocaleDateString('ar-SA', { weekday: 'short', day: 'numeric', month: 'short' })
  }

  // تنسيق الوقت
  const formatTime = (timeStr: string) => {
    if (!timeStr) return ''
    return timeStr.slice(0, 5)
  }

  // حالة SLA
  const getSlaStatus = (deadline: string) => {
    if (!deadline) return { label: '-', color: 'text-slate-400', bg: 'bg-slate-100' }
    
    const now = new Date()
    const sla = new Date(deadline)
    const hoursLeft = (sla.getTime() - now.getTime()) / (1000 * 60 * 60)
    
    if (hoursLeft < 0) return { label: '❌ تجاوز', color: 'text-red-600', bg: 'bg-red-50' }
    if (hoursLeft < 2) return { label: '⚠️ قارب', color: 'text-orange-600', bg: 'bg-orange-50' }
    if (hoursLeft < 6) return { label: `⏰ ${Math.floor(hoursLeft)} س`, color: 'text-amber-600', bg: 'bg-amber-50' }
    return { label: '✅ ضمن SLA', color: 'text-green-600', bg: 'bg-green-50' }
  }

  // حالة الطلب
  const getStatusBadge = (status: string) => {
    const statuses: Record<string, { label: string; color: string }> = {
      'new': { label: 'جديد', color: 'bg-amber-100 text-amber-700' },
      'in_progress': { label: 'قيد التنفيذ', color: 'bg-blue-100 text-blue-700' },
      'completed': { label: 'مكتمل', color: 'bg-green-100 text-green-700' },
      'overdue': { label: 'متأخر', color: 'bg-red-100 text-red-700' },
      'active': { label: 'نشطة', color: 'bg-green-100 text-green-700' },
      'pending': { label: 'معلقة', color: 'bg-amber-100 text-amber-700' },
    }
    return statuses[status] || { label: status, color: 'bg-slate-100 text-slate-700' }
  }

  // التغيير الأسبوعي
  const getChangeIndicator = (change: number) => {
    if (change > 0) return { icon: '↑', color: 'text-green-600', text: `+${change}` }
    if (change < 0) return { icon: '↓', color: 'text-red-600', text: `${change}` }
    return { icon: '-', color: 'text-slate-400', text: '0' }
  }

  // ─────────────────────────────────────────────────────────────
  // شاشة التحميل
  // ─────────────────────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-500">جاري تحميل البيانات...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      
      {/* ═══════════════════════════════════════════════════════════ */}
      {/* بطاقات الإحصائيات - كل بطاقة قابلة للنقر */}
      {/* ═══════════════════════════════════════════════════════════ */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        
        {/* طلبات جديدة */}
        <Link 
          href="/legal-arm-lawyer/requests?status=new"
          className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 hover:shadow-md hover:border-amber-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-2xl">📥</span>
            <span className={`text-xs font-medium ${getChangeIndicator(stats.newRequestsChange).color}`}>
              {getChangeIndicator(stats.newRequestsChange).icon} {getChangeIndicator(stats.newRequestsChange).text}
            </span>
          </div>
          <p className="text-3xl font-bold text-slate-800 group-hover:text-amber-600 transition-colors">
            {stats.newRequests}
          </p>
          <p className="text-sm text-slate-500 mt-1">طلبات جديدة</p>
        </Link>

        {/* قيد التنفيذ */}
        <Link 
          href="/legal-arm-lawyer/requests?status=in_progress"
          className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 hover:shadow-md hover:border-amber-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-2xl">⏳</span>
            <span className={`text-xs font-medium ${getChangeIndicator(stats.inProgressChange).color}`}>
              {getChangeIndicator(stats.inProgressChange).icon} {getChangeIndicator(stats.inProgressChange).text}
            </span>
          </div>
          <p className="text-3xl font-bold text-slate-800 group-hover:text-amber-600 transition-colors">
            {stats.inProgress}
          </p>
          <p className="text-sm text-slate-500 mt-1">قيد التنفيذ</p>
        </Link>

        {/* متأخرة SLA */}
        <Link 
          href="/legal-arm-lawyer/requests?status=overdue"
          className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 hover:shadow-md hover:border-red-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-2xl">⚠️</span>
            <span className={`text-xs font-medium ${getChangeIndicator(stats.overdueChange).color}`}>
              {getChangeIndicator(stats.overdueChange).icon} {getChangeIndicator(stats.overdueChange).text}
            </span>
          </div>
          <p className={`text-3xl font-bold ${stats.overdue > 0 ? 'text-red-600' : 'text-slate-800'} group-hover:text-red-700 transition-colors`}>
            {stats.overdue}
          </p>
          <p className="text-sm text-slate-500 mt-1">متأخرة SLA</p>
        </Link>

        {/* قضايا نشطة */}
        <Link 
          href="/legal-arm-lawyer/cases?status=active"
          className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 hover:shadow-md hover:border-amber-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-2xl">⚖️</span>
            <span className={`text-xs font-medium ${getChangeIndicator(stats.activeCasesChange).color}`}>
              {getChangeIndicator(stats.activeCasesChange).icon} {getChangeIndicator(stats.activeCasesChange).text}
            </span>
          </div>
          <p className="text-3xl font-bold text-slate-800 group-hover:text-amber-600 transition-colors">
            {stats.activeCases}
          </p>
          <p className="text-sm text-slate-500 mt-1">قضايا نشطة</p>
        </Link>

        {/* تقييمي */}
        <Link 
          href="/legal-arm-lawyer/profile#ratings"
          className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 hover:shadow-md hover:border-amber-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-2xl">⭐</span>
          </div>
          <p className="text-3xl font-bold text-amber-600 group-hover:text-amber-700 transition-colors">
            {stats.avgRating.toFixed(1)}
          </p>
          <p className="text-sm text-slate-500 mt-1">
            تقييمي ({stats.totalRatings} تقييم)
          </p>
        </Link>
      </div>

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* الجلسات القادمة + الإشعارات */}
      {/* ═══════════════════════════════════════════════════════════ */}
      <div className="grid lg:grid-cols-2 gap-6">
        
        {/* الجلسات القادمة */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-semibold text-slate-800 flex items-center gap-2">
              <span>📅</span> الجلسات القادمة
            </h3>
            <Link 
              href="/legal-arm-lawyer/calendar"
              className="text-sm text-amber-600 hover:text-amber-700 font-medium"
            >
              عرض التقويم ←
            </Link>
          </div>
          <div className="p-4">
            {sessions.length === 0 ? (
              <p className="text-center text-slate-400 py-8">لا توجد جلسات قادمة</p>
            ) : (
              <div className="space-y-3">
                {sessions.map((session) => (
                  <Link
                    key={session.id}
                    href={`/legal-arm-lawyer/calendar?date=${session.date}`}
                    className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors"
                  >
                    <div className="w-12 h-12 bg-amber-50 rounded-xl flex flex-col items-center justify-center">
                      <span className="text-xs text-amber-600 font-medium">
                        {formatDate(session.date)}
                      </span>
                      <span className="text-sm font-bold text-amber-700">
                        {formatTime(session.time)}
                      </span>
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-slate-800">{session.title}</p>
                      <p className="text-sm text-slate-500">{session.type}</p>
                    </div>
                    <span className="text-slate-400">←</span>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* آخر الإشعارات */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-semibold text-slate-800 flex items-center gap-2">
              <span>🔔</span> آخر الإشعارات
            </h3>
            <Link 
              href="/legal-arm-lawyer/notifications"
              className="text-sm text-amber-600 hover:text-amber-700 font-medium"
            >
              عرض الكل ←
            </Link>
          </div>
          <div className="p-4">
            {notifications.length === 0 ? (
              <p className="text-center text-slate-400 py-8">لا توجد إشعارات</p>
            ) : (
              <div className="space-y-3">
                {notifications.map((notif) => (
                  <Link
                    key={notif.id}
                    href="/legal-arm-lawyer/notifications"
                    className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors"
                  >
                    <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center">
                      <span className="text-lg">
                        {notif.type === 'request' ? '📋' : 
                         notif.type === 'rating' ? '⭐' : 
                         notif.type === 'reminder' ? '⏰' : '🔔'}
                      </span>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-slate-800">{notif.title}</p>
                      <p className="text-xs text-slate-400">
                        {new Date(notif.created_at).toLocaleDateString('ar-SA')}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* الطلبات الحالية */}
      {/* ═══════════════════════════════════════════════════════════ */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-semibold text-slate-800 flex items-center gap-2">
            <span>📋</span> الطلبات الحالية
          </h3>
          <Link 
            href="/legal-arm-lawyer/requests"
            className="text-sm text-amber-600 hover:text-amber-700 font-medium"
          >
            عرض الكل ←
          </Link>
        </div>
        
        {requests.length === 0 ? (
          <div className="p-8 text-center text-slate-400">
            <span className="text-4xl mb-2 block">📭</span>
            <p>لا توجد طلبات حالية</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="text-right px-4 py-3 text-sm font-medium text-slate-600">رقم الطلب</th>
                  <th className="text-right px-4 py-3 text-sm font-medium text-slate-600">النوع</th>
                  <th className="text-right px-4 py-3 text-sm font-medium text-slate-600">المجال</th>
                  <th className="text-right px-4 py-3 text-sm font-medium text-slate-600">الحالة</th>
                  <th className="text-right px-4 py-3 text-sm font-medium text-slate-600">SLA</th>
                  <th className="text-right px-4 py-3 text-sm font-medium text-slate-600"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {requests.map((request) => {
                  const sla = getSlaStatus(request.sla_deadline)
                  const statusBadge = getStatusBadge(request.status)
                  return (
                    <tr key={request.id} className="hover:bg-slate-50">
                      <td className="px-4 py-3">
                        <span className="font-medium text-slate-800">{request.request_number}</span>
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-600">{request.service_type}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{request.domain}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${statusBadge.color}`}>
                          {statusBadge.label}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex px-2 py-1 rounded-lg text-xs font-medium ${sla.bg} ${sla.color}`}>
                          {sla.label}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <Link
                          href={`/legal-arm-lawyer/requests/${request.id}`}
                          className="text-amber-600 hover:text-amber-700 text-sm font-medium"
                        >
                          عرض ←
                        </Link>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ═══════════════════════════════════════════════════════════ */}
      {/* القضايا النشطة */}
      {/* ═══════════════════════════════════════════════════════════ */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-semibold text-slate-800 flex items-center gap-2">
            <span>⚖️</span> القضايا النشطة
          </h3>
          <Link 
            href="/legal-arm-lawyer/cases"
            className="text-sm text-amber-600 hover:text-amber-700 font-medium"
          >
            عرض الكل ←
          </Link>
        </div>
        
        {cases.length === 0 ? (
          <div className="p-8 text-center text-slate-400">
            <span className="text-4xl mb-2 block">⚖️</span>
            <p>لا توجد قضايا نشطة</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="text-right px-4 py-3 text-sm font-medium text-slate-600">رقم القضية</th>
                  <th className="text-right px-4 py-3 text-sm font-medium text-slate-600">العميل</th>
                  <th className="text-right px-4 py-3 text-sm font-medium text-slate-600">المحكمة</th>
                  <th className="text-right px-4 py-3 text-sm font-medium text-slate-600">الجلسة القادمة</th>
                  <th className="text-right px-4 py-3 text-sm font-medium text-slate-600">الحالة</th>
                  <th className="text-right px-4 py-3 text-sm font-medium text-slate-600"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {cases.map((caseItem) => {
                  const statusBadge = getStatusBadge(caseItem.status)
                  return (
                    <tr key={caseItem.id} className="hover:bg-slate-50">
                      <td className="px-4 py-3">
                        <span className="font-medium text-slate-800">{caseItem.case_number}</span>
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-600">{caseItem.client_name}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{caseItem.court_name}</td>
                      <td className="px-4 py-3 text-sm text-slate-600">{formatDate(caseItem.next_session)}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${statusBadge.color}`}>
                          {statusBadge.label}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <Link
                          href={`/legal-arm-lawyer/cases/${caseItem.id}`}
                          className="text-amber-600 hover:text-amber-700 text-sm font-medium"
                        >
                          عرض ←
                        </Link>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  )
}
