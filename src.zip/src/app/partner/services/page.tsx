'use client'

import ServicesManager from '@/components/services/ServicesManager'

export default function PartnerServicesPage() {
  return <ServicesManager providerType="partner" />
}
