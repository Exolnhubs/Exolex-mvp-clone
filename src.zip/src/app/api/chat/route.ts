import { NextRequest, NextResponse } from 'next/server'
import OpenAI from 'openai'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

const LEGAL_TOPICS = [
  'عمل', 'عمال', 'موظف', 'راتب', 'فصل', 'استقالة', 'عقد', 'إجازة', 'مكافأة', 'نهاية الخدمة',
  'طلاق', 'زواج', 'حضانة', 'نفقة', 'أحوال شخصية', 'ميراث', 'وصية',
  'إيجار', 'عقار', 'ملكية', 'بيع', 'شراء',
  'تجاري', 'شركة', 'سجل', 'تأسيس', 'شراكة',
  'إقامة', 'كفالة', 'تأشيرة', 'جواز', 'نقل كفالة',
  'قضية', 'محكمة', 'دعوى', 'حكم', 'استئناف',
  'جنائي', 'جريمة', 'سرقة', 'احتيال',
  'حق', 'حقوق', 'قانون', 'نظام', 'لائحة', 'مادة',
  'تعويض', 'ضرر', 'مخالفة', 'غرامة',
  'صياغة', 'نموذج', 'اتفاقية', 'توكيل', 'وكالة'
]

function isLegalQuestion(question: string): boolean {
  const lowerQuestion = question.toLowerCase()
  return LEGAL_TOPICS.some(topic => lowerQuestion.includes(topic))
}

const SYSTEM_PROMPT = `أنت NOLEX، المستشار القانوني الذكي لمنصة ExoLex المتخصصة في الأنظمة السعودية.

## نطاق عملك المحدد:
أنت متخصص فقط في:
- نظام العمل والعمال السعودي
- نظام الأحوال الشخصية (زواج، طلاق، حضانة، نفقة)
- الأنظمة التجارية والشركات
- نظام الإيجار والعقارات
- نظام الإقامة والكفالة
- الأنظمة الجزائية
- صياغة العقود والاتفاقيات
- نماذج قانونية
- حقوق المستهلك

## قاعدة ذهبية - الرفض المهذب:
إذا كان السؤال خارج النطاق القانوني (مثل: طبخ، رياضة، تقنية، هندسة، طب، سفر، ترفيه، أو أي موضوع غير قانوني):

أجب بـ:
"OUT_OF_SCOPE: عذراً، أنا NOLEX متخصص في الاستشارات القانونية والأنظمة السعودية فقط. 

يمكنني مساعدتك في:
- قضايا العمل والموظفين
- الأحوال الشخصية والأسرة
- العقود والاتفاقيات
- نظام الإقامة والكفالة
- القضايا التجارية

كيف يمكنني مساعدتك في أحد هذه المجالات؟"

ابدأ الرد بـ OUT_OF_SCOPE: فقط إذا كان السؤال خارج النطاق.

## أسلوب الإجابة للأسئلة القانونية:
- كن صديقاً ومستشاراً يبسط الأمور
- اعرض جميع الحالات المحتملة بدلاً من طرح أسئلة
- اذكر رقم المادة والنظام عند الاستشهاد
- قدم نصائح عملية
- اختم بـ: "هذه معلومات عامة، وأنصحك بمراجعة التفاصيل حسب حالتك الخاصة."

## تنسيق الإجابة:
- استخدم 📌 للحالات المختلفة
- استخدم 💡 للنصائح العملية
- استخدم ⚠️ للتحذيرات المهمة`

export async function POST(request: NextRequest) {
  try {
    const { question, context } = await request.json()

    if (!question) {
      return NextResponse.json(
        { error: 'السؤال مطلوب' },
        { status: 400 }
      )
    }

    // فحص أولي سريع
    const likelyLegal = isLegalQuestion(question)

    const messages: OpenAI.ChatCompletionMessageParam[] = [
      { role: 'system', content: SYSTEM_PROMPT },
    ]

    if (context) {
      messages.push({
        role: 'system',
        content: `السياق من المكتبة القانونية:\n${context}`
      })
    }

    messages.push({ role: 'user', content: question })

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages,
      temperature: 0.4,
      max_tokens: 2000,
    })

    let answer = completion.choices[0]?.message?.content || 'لم أتمكن من الإجابة'
    
    // تحقق إذا كان خارج النطاق
    const isOutOfScope = answer.startsWith('OUT_OF_SCOPE:')
    
    // إزالة العلامة من الرد
    if (isOutOfScope) {
      answer = answer.replace('OUT_OF_SCOPE:', '').trim()
    }

    return NextResponse.json({
      answer,
      isOutOfScope,
      model: completion.model,
      tokens: completion.usage?.total_tokens || 0,
    })

  } catch (error: any) {
    console.error('OpenAI Error:', error)
    
    if (error?.code === 'insufficient_quota') {
      return NextResponse.json(
        { error: 'انتهى رصيد OpenAI API' },
        { status: 402 }
      )
    }

    return NextResponse.json(
      { error: 'حدث خطأ في معالجة السؤال' },
      { status: 500 }
    )
  }
}
