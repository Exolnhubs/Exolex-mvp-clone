'use client'

import { useState, useRef, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import toast from 'react-hot-toast'
import Image from 'next/image'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
}

interface UserQuota {
  id: string
  searches_used: number
  searches_remaining: number
}

export default function FloatingNolex() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [inputMessage, setInputMessage] = useState('')
  const [isSending, setIsSending] = useState(false)
  const [userId, setUserId] = useState<string | null>(null)
  const [userQuota, setUserQuota] = useState<UserQuota | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const id = localStorage.getItem('exolex_user_id')
    setUserId(id)
    if (id) fetchQuota(id)
  }, [])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const fetchQuota = async (uid: string) => {
    const { data } = await supabase
      .from('kb_user_quotas')
      .select('*')
      .eq('user_id', uid)
      .eq('status', 'active')
      .single()
    
    if (data) {
      setUserQuota(data)
    } else {
      // إنشاء حصة مجانية جديدة إذا لم توجد
      const { data: freePackage } = await supabase
        .from('kb_quota_packages')
        .select('*')
        .eq('code', 'free')
        .single()
      
      if (freePackage) {
        const { data: newQuota } = await supabase
          .from('kb_user_quotas')
          .insert({
            user_id: uid,
            package_id: freePackage.id,
            searches_remaining: freePackage.searches_limit,
            searches_used: 0,
            period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
          })
          .select()
          .single()
        if (newQuota) setUserQuota(newQuota)
      }
    }
  }

  const sendMessage = async () => {
    if (!inputMessage.trim() || isSending) return

    // التحقق من الرصيد
    if (!userQuota || userQuota.searches_remaining <= 0) {
      toast.error('انتهى رصيد البحث! اشترِ باقة جديدة من المكتبة')
      return
    }

    const text = inputMessage.trim()
    setInputMessage('')
    setIsSending(true)

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text
    }
    setMessages(prev => [...prev, userMessage])

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: text })
      })
      const data = await response.json()

      if (!response.ok) throw new Error(data.error || 'حدث خطأ')

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.answer
      }
      setMessages(prev => [...prev, assistantMessage])

      // خصم من الرصيد فقط إذا كان ضمن النطاق
      if (!data.isOutOfScope && userQuota) {
        await supabase
          .from('kb_user_quotas')
          .update({
            searches_used: userQuota.searches_used + 1,
            searches_remaining: userQuota.searches_remaining - 1
          })
          .eq('id', userQuota.id)

        setUserQuota({
          ...userQuota,
          searches_used: userQuota.searches_used + 1,
          searches_remaining: userQuota.searches_remaining - 1
        })
      }

      // حفظ في سجل المكتبة
      if (userId) {
        await supabase.from('kb_search_history').insert({
          user_id: userId,
          question_text: text,
          answer_text: data.answer,
          is_out_of_scope: data.isOutOfScope || false,
          tokens_used: data.tokens || 0
        })
      }

    } catch (error) {
      toast.error('حدث خطأ، حاول مرة أخرى')
    } finally {
      setIsSending(false)
    }
  }

  const clearChat = () => {
    setMessages([])
  }

  if (!userId) return null

  return (
    <>
      {/* الزر العائم مع صورة نولكس */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 left-6 z-50 w-16 h-16 rounded-full shadow-xl flex items-center justify-center transition-all duration-300 hover:scale-110 overflow-hidden ${
          isOpen 
            ? 'bg-gradient-to-r from-red-500 to-red-600' 
            : 'bg-white border-2 border-primary-500'
        }`}
      >
        {isOpen ? (
          <span className="text-2xl text-white">✕</span>
        ) : (
          <Image
            src="/nolex-avatar.jpg"
            alt="NOLEX"
            width={64}
            height={64}
            className="w-full h-full object-cover"
          />
        )}
      </button>

      {/* Badge الرصيد */}
      {!isOpen && (
        <div className="fixed bottom-24 left-6 z-50 bg-primary-600 text-white text-sm px-3 py-1.5 rounded-full shadow-lg animate-bounce">
          اسألني! 💬
        </div>
      )}

      {!isOpen && userQuota && (
        <div className="fixed bottom-20 left-6 z-50 bg-white text-xs px-2 py-1 rounded-full shadow-md border">
          <span className={userQuota.searches_remaining > 3 ? 'text-green-600' : 'text-red-600'}>
            {userQuota.searches_remaining} بحث
          </span>
        </div>
      )}

      {/* نافذة المحادثة */}
      {isOpen && (
        <div className="fixed bottom-24 left-6 z-50 w-96 h-[520px] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden border-2 border-primary-100">
          {/* Header */}
          <div className="bg-gradient-to-r from-primary-600 to-primary-700 text-white p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-white/30">
                  <Image
                    src="/nolex-avatar.jpg"
                    alt="NOLEX"
                    width={48}
                    height={48}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="font-bold">NOLEX</h3>
                  <p className="text-xs opacity-80">المساعد القانوني الذكي</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {userQuota && (
                  <span className="bg-white/20 text-xs px-2 py-1 rounded-full">
                    {userQuota.searches_remaining} 🔍
                  </span>
                )}
                <button
                  onClick={clearChat}
                  className="text-white/70 hover:text-white p-1"
                  title="مسح المحادثة"
                >
                  🗑️
                </button>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gradient-to-b from-gray-50 to-white">
            {messages.length === 0 ? (
              <div className="text-center py-6">
                <div className="w-20 h-20 rounded-full overflow-hidden mx-auto mb-4 border-4 border-primary-100">
                  <Image
                    src="/nolex-avatar.jpg"
                    alt="NOLEX"
                    width={80}
                    height={80}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h4 className="font-bold text-gray-700 mb-1">مرحباً! أنا NOLEX</h4>
                <p className="text-sm text-gray-500 mb-4">اسألني أي سؤال قانوني</p>
                <div className="space-y-2">
                  {['ما حقوقي إذا تأخر راتبي؟', 'كيف أرفع قضية عمالية؟'].map((q, i) => (
                    <button
                      key={i}
                      onClick={() => setInputMessage(q)}
                      className="block w-full text-xs bg-white border rounded-lg px-3 py-2 hover:bg-gray-50 text-gray-600"
                    >
                      {q}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-gray-400 mt-4">📚 المحادثات تُحفظ في المكتبة</p>
              </div>
            ) : (
              messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}
                >
                  <div
                    className={`max-w-[85%] p-3 rounded-2xl text-sm ${
                      msg.role === 'user'
                        ? 'bg-primary-600 text-white rounded-tr-sm'
                        : 'bg-white border shadow-sm rounded-tl-sm'
                    }`}
                  >
                    <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                  </div>
                </div>
              ))
            )}
            {isSending && (
              <div className="flex justify-end">
                <div className="bg-white border p-3 rounded-2xl rounded-tl-sm shadow-sm">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 bg-primary-400 rounded-full animate-bounce"></span>
                    <span className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></span>
                    <span className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-3 border-t bg-white">
            <div className="flex gap-2">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                placeholder="اكتب سؤالك القانوني..."
                className="flex-1 border-2 border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                disabled={isSending}
              />
              <button
                onClick={sendMessage}
                disabled={isSending || !inputMessage.trim()}
                className="bg-primary-600 text-white px-5 py-2.5 rounded-xl hover:bg-primary-700 disabled:opacity-50 transition-colors"
              >
                {isSending ? '...' : '↑'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
